# replit.md

## Overview

This is a comprehensive 3D empire-building and kingdom defense game combining Thronefall's tactical defense mechanics with Rise of Kingdoms' strategic empire management. Players defend their kingdom through wave-based battles while simultaneously managing a growing empire with city building, technology research, resource management, troop training, and territorial expansion. The game features multi-layered gameplay spanning from tactical combat to grand strategy.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the UI framework
- **React Three Fiber** for 3D rendering and game world
- **Three.js** ecosystem with @react-three/drei for 3D utilities
- **Tailwind CSS** with shadcn/ui components for styling
- **Zustand** for state management across game systems
- **TanStack Query** for server state management
- **Vite** as the build tool with custom configuration for 3D assets

### Backend Architecture
- **Express.js** server with TypeScript
- **Drizzle ORM** with PostgreSQL database schema
- **Neon Database** (@neondatabase/serverless) for database connectivity
- RESTful API structure with `/api` prefix
- In-memory storage fallback for development

### State Management
The game uses multiple Zustand stores for different gameplay layers:

**Tactical Defense Layer (Thronefall-inspired):**
- `useGameState`: Game phases, wave management, victory/defeat conditions, multi-biome progression
- `useBuildings`: Building placement, types, health, and validation with upgrade systems
- `useEnemies`: Enemy spawning, movement, combat, and pathfinding with 7 authentic Thronefall enemy types
- `useResources`: Gold and lives management for immediate battle needs
- `useAudio`: Sound effects and music control
- `useHero`: Hero classes (knight/archer/mage), skill trees, experience, and abilities

**Strategic Empire Layer (Rise of Kingdoms-inspired):**
- `useEmpire`: Comprehensive empire management with 5 resource types (food, wood, stone, gold, power)
- City building with economic, military, research, and infrastructure structures
- Technology research trees across agriculture, construction, military, research, and economy
- Population and happiness management systems
- Alliance mechanics and territorial control

**Advanced Systems:**
- `useWeather`: Dynamic weather effects affecting gameplay
- `useBosses`: Boss siege encounters every 5 waves
- `useCrafting`: Tower modification system with essence-based crafting
- `useQuests`: Side quest system with rescue, escort, and hunting missions
- `useHazards`: Environmental traps and hazards for strategic gameplay

## Key Components

### Core Game Systems
1. **Hero System**: Choose from knight, archer, or mage with unique skill trees and abilities
2. **Building System**: Place towers, walls, houses, barracks, and throne with grid-based placement
3. **Enemy System**: 7 authentic Thronefall enemy types (peasant, archer, swordsman, spearman, ogre, racer, exploder) with golden variants
4. **Combat System**: Tower attacks, hero abilities, building damage, enemy pathfinding with special behaviors
5. **Resource Management**: Gold generation, crafting materials (essence, wood, stone, metal)
6. **Wave System**: Progressive difficulty with boss sieges every 5 waves

### Advanced Features
7. **Weather System**: Dynamic weather events affecting gameplay (winter freeze, storms, floods)
8. **Crafting System**: Forge tower modifications using gathered materials for enhanced abilities
9. **Quest System**: Side missions including caravan rescue, merchant escort, and bandit hunting
10. **Environmental Hazards**: Collapsible bridges, rockslides, tar pits, and spike traps
11. **Boss Encounters**: Unique boss enemies with special mechanics and weaknesses

### 3D Rendering
- **Terrain**: Grass-textured ground plane
- **Buildings**: Colored 3D boxes with health bars and shadows
- **Enemies**: Moving 3D entities with pathfinding
- **Lighting**: Ambient and directional lighting with shadow mapping
- **Camera**: Fixed isometric perspective optimized for strategy gameplay

### UI Components
- **Game HUD**: Resource display, wave information, building controls
- **Building Panel**: Selection interface for different building types
- **Audio Controls**: Mute/unmute functionality
- **Phase Management**: Ready, playing, victory, and game over screens

## Data Flow

1. **Game Loop**: Uses React Three Fiber's `useFrame` for 60fps game logic updates
2. **State Updates**: Zustand stores handle all game state mutations
3. **Rendering**: React Three Fiber components subscribe to state changes
4. **User Input**: Mouse interactions for building placement and UI controls
5. **Audio System**: Centralized audio management with mute controls

## External Dependencies

### Core Dependencies
- **React Ecosystem**: react, react-dom, @types/react
- **3D Graphics**: three, @react-three/fiber, @react-three/drei, @react-three/postprocessing
- **State Management**: zustand, @tanstack/react-query
- **UI Framework**: @radix-ui components, tailwindcss, class-variance-authority
- **Database**: drizzle-orm, drizzle-kit, @neondatabase/serverless
- **Build Tools**: vite, typescript, esbuild

### Development Tools
- **TypeScript**: Full type safety across client and server
- **Vite Plugins**: GLSL shader support, runtime error overlay
- **Asset Support**: GLTF/GLB models, audio files (MP3, OGG, WAV)

## Deployment Strategy

### Build Process
1. **Client Build**: Vite builds React app to `dist/public`
2. **Server Build**: esbuild bundles Express server to `dist/index.js`
3. **Database**: Drizzle migrations applied via `db:push` command

### Runtime Configuration
- **Development**: `npm run dev` runs server with Vite middleware
- **Production**: `npm run start` serves built files
- **Database**: PostgreSQL via environment variable `DATABASE_URL`

### Replit Configuration
- **Deployment Target**: Autoscale
- **Port Configuration**: Internal 5000, external 80
- **Build Command**: `npm run build`
- **Run Command**: `npm run start`

### Standalone Executable (Electron)
- **Desktop App**: Electron packages the game as a standalone .exe file
- **Build Command**: `node build-electron.js` creates Windows installer
- **Distribution**: Self-contained executable requiring no Node.js installation
- **File Size**: ~150-200 MB installer, ~300-400 MB installed
- **Compatibility**: Works on any Windows machine without dependencies

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### June 22, 2025 - Empire Transformation
- **Thronefall + Rise of Kingdoms Integration**: Transformed the game into a dual-layer experience combining tactical tower defense with strategic empire management.

- **Empire Management System**: Added comprehensive empire building features:
  - **5 Resource Economy**: Food, wood, stone, gold, and power with production chains
  - **Technology Research**: 5 research trees (agriculture, construction, military, research, economy) with prerequisites and bonuses
  - **City Building**: Economic, military, research, and infrastructure buildings with upgrade systems
  - **Population & Happiness**: City management with population caps and happiness mechanics

- **Strategic World Map**: Implemented territorial conquest system:
  - **Territory Control**: Interactive world map with 5 territories across different biomes
  - **Army Power System**: Military strength calculation based on troops and technology
  - **Conquest Mechanics**: Attack territories based on army power requirements
  - **Victory Rewards**: Resource gains and territorial expansion benefits

- **Military Commander Interface**: Added comprehensive troop training system:
  - **6 Troop Types**: Infantry, ranged, cavalry, and siege units with unique stats
  - **Training Queues**: Time-based troop production with resource costs
  - **Army Composition**: Strategic unit combinations for different combat scenarios

- **Integrated Gameplay Loop**: Seamless connection between tactical defense battles and strategic empire progression with resource flow between systems.

## Changelog

Changelog:
- June 22, 2025. Initial setup with comprehensive Thronefall-inspired tower defense game
- June 22, 2025. Added winning system, map progression, and enhanced building structures