const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('Building Empire Defense Electron App...\n');

try {
  // Step 1: Build the web application
  console.log('Step 1: Building web application...');
  execSync('npx vite build', { stdio: 'inherit' });
  
  console.log('Building server...');
  execSync('npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist', { stdio: 'inherit' });
  console.log('Web build complete\n');

  // Step 2: Build the executable using package-electron.json
  console.log('Step 2: Building executable...');
  execSync('npx electron-builder --config package-electron.json --win --x64', { stdio: 'inherit' });
  
  console.log('\nBuild complete!');
  console.log('Your executable is in the "electron-dist" folder');
  console.log('Look for "Empire Defense Setup 1.0.0.exe" to install your game');
  
} catch (error) {
  console.error('Build failed:', error.message);
  console.log('\nTroubleshooting:');
  console.log('1. Make sure you ran "npm install" first');
  console.log('2. Check that you have enough disk space (need ~500MB)');
  console.log('3. Try running "npm run build" separately first');
  process.exit(1);
}