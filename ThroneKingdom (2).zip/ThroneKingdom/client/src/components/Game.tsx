import { useFrame } from "@react-three/fiber";
import { useEffect } from "react";
import * as THREE from "three";
import Terrain from "./Terrain";
import Buildings from "./Buildings";
import Enemies from "./Enemies";
import GridOverlay from "./GridOverlay";
import Hero from "./Hero";
import { useGameState } from "../lib/stores/useGameState";
import { useBuildings } from "../lib/stores/useBuildings";
import { useEnemies } from "../lib/stores/useEnemies";
import { useResources } from "../lib/stores/useResources";
import { useAudio } from "../lib/stores/useAudio";
import { useEmpire } from "../lib/stores/useEmpire";
import { updateGameLogic } from "../lib/gameLogic";
import WorldMap from "./WorldMap";
import MilitaryCommander from "./MilitaryCommander";
import GameUI from "./GameUI"; // Assuming GameUI exists and is needed

export default function Game() {
  const { phase, currentWave, startWave, endWave } = useGameState();
  const { buildings, updateUpgrades, updateResourceProduction } = useBuildings();
  const { enemies, updateEnemies } = useEnemies();
  const { gold, addGold } = useResources();
  const { playHit, playSuccess } = useAudio();
  const { updateProduction, updateUpgrades: updateEmpireUpgrades, updateResearch, addResource } = useEmpire();

  // Initialize audio
  useEffect(() => {
    const hitAudio = new Audio('/sounds/hit.mp3');
    const successAudio = new Audio('/sounds/success.mp3');
    const bgAudio = new Audio('/sounds/background.mp3');

    bgAudio.loop = true;
    bgAudio.volume = 0.3;

    // Set audio in store (for mute functionality)
    // Audio management is handled by the existing useAudio store
  }, []);

  // Game loop
  useFrame((state, delta) => {
    // Update building upgrades (defense)
    updateUpgrades(delta);

    // Update resource production from buildings
    updateResourceProduction(delta);

    // Update empire systems (city management)
    updateProduction(delta);
    updateEmpireUpgrades(delta);
    updateResearch(delta);

    // Convert gold to empire gold periodically
    if (Math.random() < 0.01) { // 1% chance per frame
      addResource("gold", Math.floor(gold * 0.1));
    }

    updateGameLogic(delta, {
      phase,
      currentWave,
      buildings,
      enemies,
      updateEnemies,
      startWave,
      endWave,
      addGold,
      playHit,
      playSuccess
    });
  });

  return (
    <>
      <Terrain />
      <Buildings />
      <Enemies />
      <GridOverlay />
      <Hero />
    </>
  );
}