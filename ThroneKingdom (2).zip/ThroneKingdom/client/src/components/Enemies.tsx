import { useFrame } from "@react-three/fiber";
import { useRef, memo } from "react";
import { useEnemies } from "../lib/stores/useEnemies";
import * as THREE from "three";

const Enemy = memo(({ enemy }: { enemy: any }) => {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.position.set(enemy.x, 0.25, enemy.z);
    }
  });

  const colors: Record<string, string> = {
    peasant: '#8B4513',     // Brown - basic worker
    archer: '#2E8B57',      // Sea green - archer
    swordsman: '#4682B4',   // Steel blue - armored
    spearman: '#800080',    // Purple - spear unit
    ogre: '#8B0000',        // Dark red - large threat
    racer: '#FF6347',       // Tomato red - fast unit
    exploder: '#FF4500',    // Orange red - explosive
    wizard: '#9370DB',      // Medium purple - magical
    berserker: '#DC143C',   // Crimson - rage fighter
    giant: '#2F4F4F',       // Dark slate gray - massive
    assassin: '#000000',    // Black - stealth
    necromancer: '#4B0082'  // Indigo - dark magic
  };

  const goldenColor = '#FFD700'; // Gold color for golden enemies

  // Adjust size based on enemy type
  const sizes: Record<string, [number, number, number]> = {
    peasant: [0.3, 0.4, 0.3],
    archer: [0.3, 0.5, 0.3],
    swordsman: [0.4, 0.6, 0.4],
    spearman: [0.35, 0.55, 0.35],
    ogre: [0.6, 0.8, 0.6],
    racer: [0.25, 0.3, 0.25],
    exploder: [0.35, 0.35, 0.35],
    wizard: [0.4, 0.7, 0.4],
    berserker: [0.5, 0.7, 0.5],
    giant: [0.8, 1.2, 0.8],
    assassin: [0.3, 0.4, 0.3],
    necromancer: [0.45, 0.8, 0.45]
  };

  const enemyColor = enemy.isGolden ? goldenColor : colors[enemy.type];
  const size = sizes[enemy.type] || [0.4, 0.5, 0.4];

  return (
    <mesh ref={meshRef} castShadow>
      <boxGeometry args={size} />
      <meshLambertMaterial color={enemyColor} />
      
      {/* Health bar */}
      {enemy.health < enemy.maxHealth && (
        <mesh position={[0, size[1] + 0.1, 0]}>
          <planeGeometry args={[size[0] + 0.1, 0.05]} />
          <meshBasicMaterial 
            color={enemy.health / enemy.maxHealth > 0.5 ? 'green' : 'red'} 
            transparent 
            opacity={0.8}
          />
        </mesh>
      )}
      
      {/* Golden enemy indicator */}
      {enemy.isGolden && (
        <mesh position={[0, size[1] + 0.2, 0]}>
          <sphereGeometry args={[0.05]} />
          <meshBasicMaterial color={goldenColor} />
        </mesh>
      )}
    </mesh>
  );
});

export default function Enemies() {
  const { enemies } = useEnemies();

  return (
    <>
      {enemies.map((enemy) => (
        <Enemy key={enemy.id} enemy={enemy} />
      ))}
    </>
  );
}
