import { useGameState } from "../lib/stores/useGameState";
import { useEmpire } from "../lib/stores/useEmpire";
import { useBuildings } from "../lib/stores/useBuildings";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  Crown, 
  Users, 
  Building, 
  Zap, 
  TrendingUp,
  Award,
  Timer,
  Target
} from "lucide-react";

export default function GameStats() {
  const { currentWave, phase } = useGameState();
  const { resources, population, happiness, armyPower } = useEmpire();
  const { buildings } = useBuildings();

  const getTotalBuildings = () => buildings.length;
  const getResourceBuildings = () => buildings.filter(b => b.resourceType).length;
  const getDefenseBuildings = () => buildings.filter(b => ['tower', 'wall', 'watchtower', 'gatehouse'].includes(b.type)).length;

  const getAverageLevel = () => {
    if (buildings.length === 0) return 1;
    return Math.round(buildings.reduce((sum, b) => sum + b.level, 0) / buildings.length);
  };

  const getProgressToNextWave = () => {
    return ((currentWave - 1) % 5) * 20; // Progress towards next milestone
  };

  if (phase === 'wave') return null;

  return (
    <div className="fixed top-4 right-4 w-80 max-h-[80vh] overflow-y-auto pointer-events-auto z-20">
      <Card className="bg-black/90 text-white border-blue-500">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-500" />
            <CardTitle className="text-lg">Empire Statistics</CardTitle>
          </div>
        </CardHeader>
        
        <CardContent className="p-4 space-y-4">
          {/* Wave Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-red-500" />
                <span className="text-sm font-semibold">Wave Progress</span>
              </div>
              <Badge variant="outline" className="text-xs">
                Wave {currentWave}
              </Badge>
            </div>
            <Progress value={getProgressToNextWave()} className="h-2" />
            <div className="text-xs text-gray-400">
              Next milestone: Wave {Math.ceil(currentWave / 5) * 5}
            </div>
          </div>

          {/* Empire Overview */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-blue-400">Empire Status</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-gray-800 p-2 rounded">
                <div className="flex items-center gap-2">
                  <Users className="w-3 h-3 text-green-500" />
                  <span className="text-xs">Population</span>
                </div>
                <div className="text-sm font-bold">{population.toLocaleString()}</div>
              </div>
              <div className="bg-gray-800 p-2 rounded">
                <div className="flex items-center gap-2">
                  <Crown className="w-3 h-3 text-yellow-500" />
                  <span className="text-xs">Happiness</span>
                </div>
                <div className="text-sm font-bold">{Math.round(happiness)}%</div>
              </div>
            </div>
          </div>

          {/* Resources */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-green-400">Resources</h3>
            <div className="grid grid-cols-2 gap-1">
              {Object.entries(resources).map(([type, amount]) => (
                <div key={type} className="flex items-center justify-between bg-gray-800 p-1 rounded text-xs">
                  <span className="capitalize">{type}</span>
                  <span className="font-mono">{Math.floor(amount)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Buildings */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-orange-400">Infrastructure</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-gray-800 p-2 rounded">
                <div className="flex items-center gap-2">
                  <Building className="w-3 h-3 text-orange-500" />
                  <span className="text-xs">Buildings</span>
                </div>
                <div className="text-sm font-bold">{getTotalBuildings()}</div>
              </div>
              <div className="bg-gray-800 p-2 rounded">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-3 h-3 text-blue-500" />
                  <span className="text-xs">Avg Level</span>
                </div>
                <div className="text-sm font-bold">{getAverageLevel()}</div>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-green-400">Resource Buildings:</span>
                <span>{getResourceBuildings()}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-red-400">Defense Buildings:</span>
                <span>{getDefenseBuildings()}</span>
              </div>
            </div>
          </div>

          {/* Military */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-red-400">Military</h3>
            <div className="bg-gray-800 p-2 rounded">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-red-500" />
                <span className="text-sm">Army Power</span>
              </div>
              <div className="text-lg font-bold">{armyPower.toLocaleString()}</div>
            </div>
          </div>

          {/* Performance Tips */}
          <div className="space-y-2 pt-2 border-t border-gray-700">
            <h3 className="text-xs font-semibold text-purple-400">Tips</h3>
            <div className="text-xs text-gray-400 space-y-1">
              {happiness < 70 && (
                <div className="text-yellow-400">• Build temples to improve happiness</div>
              )}
              {getResourceBuildings() < 5 && (
                <div className="text-green-400">• Build more resource generators</div>
              )}
              {armyPower < currentWave * 100 && (
                <div className="text-red-400">• Train more troops for upcoming battles</div>
              )}
              {getAverageLevel() < 2 && (
                <div className="text-blue-400">• Upgrade buildings for better efficiency</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}