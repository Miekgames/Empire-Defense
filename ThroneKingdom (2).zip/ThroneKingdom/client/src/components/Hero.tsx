import { useRef, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useHero } from "../lib/stores/useHero";
import * as THREE from "three";

export default function Hero() {
  const { hero, moveHero, useSkill, takeDamage } = useHero();
  const { camera, raycaster, pointer } = useThree();
  const meshRef = useRef<THREE.Mesh>(null);
  const targetRef = useRef<{ x: number; z: number } | null>(null);
  const planeRef = useRef<THREE.Mesh>(null);

  useEffect(() => {
    if (!hero) return;

    const handleClick = (event: MouseEvent) => {
      if (!planeRef.current || !hero.isAlive) return;

      const rect = (event.target as HTMLCanvasElement).getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(new THREE.Vector2(x, y), camera);
      const intersects = raycaster.intersectObject(planeRef.current);

      if (intersects.length > 0) {
        const point = intersects[0].point;
        targetRef.current = { x: point.x, z: point.z };
      }
    };

    const canvas = document.querySelector('canvas');
    canvas?.addEventListener('click', handleClick);

    return () => {
      canvas?.removeEventListener('click', handleClick);
    };
  }, [hero, camera, raycaster]);

  useFrame((state, delta) => {
    if (!hero || !meshRef.current || !hero.isAlive) return;

    // Move hero towards target
    if (targetRef.current) {
      const dx = targetRef.current.x - hero.x;
      const dz = targetRef.current.z - hero.z;
      const distance = Math.sqrt(dx * dx + dz * dz);

      if (distance > 0.2) {
        const speed = 3;
        const moveX = (dx / distance) * speed * delta;
        const moveZ = (dz / distance) * speed * delta;
        
        moveHero(hero.x + moveX, hero.z + moveZ);
      } else {
        targetRef.current = null;
      }
    }

    // Update mesh position
    meshRef.current.position.set(hero.x, 0.5, hero.z);

    // Regenerate mana over time
    if (hero.mana < hero.maxMana) {
      useHero.getState().hero && useHero.setState(state => ({
        hero: state.hero ? {
          ...state.hero,
          mana: Math.min(state.hero.maxMana, state.hero.mana + 20 * delta)
        } : null
      }));
    }
  });

  if (!hero) return null;

  const colors = {
    knight: '#CD853F',
    archer: '#228B22', 
    mage: '#4169E1'
  };

  return (
    <>
      {/* Invisible plane for movement clicks */}
      <mesh 
        ref={planeRef}
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0.005, 0]}
        visible={false}
      >
        <planeGeometry args={[20, 20]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {/* Hero character */}
      {hero.isAlive && (
        <mesh ref={meshRef} castShadow>
          <boxGeometry args={[0.6, 1, 0.6]} />
          <meshLambertMaterial color={colors[hero.class]} />
          
          {/* Health bar */}
          {hero.health < hero.maxHealth && (
            <mesh position={[0, 0.8, 0]}>
              <planeGeometry args={[0.8, 0.1]} />
              <meshBasicMaterial 
                color={hero.health / hero.maxHealth > 0.5 ? 'green' : 'red'} 
                transparent 
                opacity={0.8}
              />
            </mesh>
          )}

          {/* Class indicator */}
          <mesh position={[0, 1.2, 0]}>
            <sphereGeometry args={[0.1]} />
            <meshBasicMaterial color={colors[hero.class]} />
          </mesh>
        </mesh>
      )}

      {/* Movement target indicator */}
      {targetRef.current && hero.isAlive && (
        <mesh position={[targetRef.current.x, 0.01, targetRef.current.z]}>
          <ringGeometry args={[0.2, 0.3]} />
          <meshBasicMaterial color="#ffff00" transparent opacity={0.6} />
        </mesh>
      )}
    </>
  );
}