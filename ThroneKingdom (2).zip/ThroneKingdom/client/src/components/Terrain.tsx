import * as THREE from "three";
import { useGameState, BiomeType } from "../lib/stores/useGameState";

const BiomeColors: Record<BiomeType, string> = {
  grasslands: "#4a7c59",
  desert: "#f59e0b",
  winter: "#dbeafe",
  volcanic: "#7f1d1d",
  swamp: "#065f46"
};

export default function Terrain() {
  const { currentMapId, maps } = useGameState();
  const currentMap = maps.find(map => map.id === currentMapId);
  const biome = currentMap?.biome || "grasslands";
  
  const terrainColor = BiomeColors[biome];

  return (
    <>
      {/* Main terrain */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <meshLambertMaterial color={terrainColor} />
      </mesh>
      
      {/* Biome-specific environmental elements */}
      {biome === "desert" && (
        <>
          {/* Sand dunes */}
          <mesh position={[6, 0.2, 4]} receiveShadow>
            <sphereGeometry args={[1.5, 8, 6]} />
            <meshLambertMaterial color="#fcd34d" />
          </mesh>
          <mesh position={[-4, 0.1, -6]} receiveShadow>
            <sphereGeometry args={[1.2, 8, 6]} />
            <meshLambertMaterial color="#fcd34d" />
          </mesh>
        </>
      )}
      
      {biome === "winter" && (
        <>
          {/* Ice patches */}
          <mesh position={[3, 0.01, 2]} receiveShadow>
            <boxGeometry args={[2, 0.1, 2]} />
            <meshLambertMaterial color="#bfdbfe" transparent opacity={0.8} />
          </mesh>
          <mesh position={[-5, 0.01, -3]} receiveShadow>
            <boxGeometry args={[1.5, 0.1, 1.5]} />
            <meshLambertMaterial color="#bfdbfe" transparent opacity={0.8} />
          </mesh>
        </>
      )}
      
      {biome === "volcanic" && (
        <>
          {/* Lava pools */}
          <mesh position={[4, 0.1, 3]} receiveShadow>
            <cylinderGeometry args={[1, 1, 0.2, 8]} />
            <meshLambertMaterial color="#ef4444" emissive="#7f1d1d" />
          </mesh>
          <mesh position={[-6, 0.1, -2]} receiveShadow>
            <cylinderGeometry args={[0.8, 0.8, 0.2, 8]} />
            <meshLambertMaterial color="#ef4444" emissive="#7f1d1d" />
          </mesh>
        </>
      )}
      
      {biome === "swamp" && (
        <>
          {/* Murky water patches */}
          <mesh position={[2, 0.02, 5]} receiveShadow>
            <cylinderGeometry args={[1.5, 1.5, 0.04, 12]} />
            <meshLambertMaterial color="#047857" transparent opacity={0.7} />
          </mesh>
          <mesh position={[-3, 0.02, -4]} receiveShadow>
            <cylinderGeometry args={[1.2, 1.2, 0.04, 12]} />
            <meshLambertMaterial color="#047857" transparent opacity={0.7} />
          </mesh>
        </>
      )}
    </>
  );
}
