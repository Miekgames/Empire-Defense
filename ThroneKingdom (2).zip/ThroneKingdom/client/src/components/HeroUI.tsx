import { useHero } from "../lib/stores/useHero";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Shield, Target, Sparkles, Heart, Zap } from "lucide-react";

export default function HeroUI() {
  const { hero, selectedClass, selectHeroClass, unlockSkill } = useHero();

  if (!hero && !selectedClass) {
    return (
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-auto z-10">
        <Card className="bg-black/90 text-white border-purple-500 w-96">
          <CardHeader>
            <CardTitle className="text-center text-purple-400">Choose Your Hero</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3">
              <Button
                onClick={() => selectHeroClass("knight")}
                className="flex items-center gap-3 p-4 h-auto bg-red-900/50 hover:bg-red-800/70 border border-red-500"
              >
                <Shield className="w-8 h-8" />
                <div className="text-left">
                  <div className="font-bold">Knight</div>
                  <div className="text-sm opacity-75">Tanky defender with taunt abilities</div>
                </div>
              </Button>
              
              <Button
                onClick={() => selectHeroClass("archer")}
                className="flex items-center gap-3 p-4 h-auto bg-green-900/50 hover:bg-green-800/70 border border-green-500"
              >
                <Target className="w-8 h-8" />
                <div className="text-left">
                  <div className="font-bold">Archer</div>
                  <div className="text-sm opacity-75">Ranged fighter with multi-shot</div>
                </div>
              </Button>
              
              <Button
                onClick={() => selectHeroClass("mage")}
                className="flex items-center gap-3 p-4 h-auto bg-blue-900/50 hover:bg-blue-800/70 border border-blue-500"
              >
                <Sparkles className="w-8 h-8" />
                <div className="text-left">
                  <div className="font-bold">Mage</div>
                  <div className="text-sm opacity-75">Magical caster with meteor shower</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!hero) return null;

  const expProgress = (hero.experience / (hero.level * 100)) * 100;
  const healthPercent = (hero.health / hero.maxHealth) * 100;
  const manaPercent = (hero.mana / hero.maxMana) * 100;

  return (
    <div className="absolute top-4 right-4 pointer-events-auto">
      <Card className="bg-black/90 text-white border-purple-500 w-80">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg capitalize flex items-center gap-2">
              {hero.class === "knight" && <Shield className="w-5 h-5" />}
              {hero.class === "archer" && <Target className="w-5 h-5" />}
              {hero.class === "mage" && <Sparkles className="w-5 h-5" />}
              {hero.class} - Level {hero.level}
            </CardTitle>
            <Badge variant="outline" className="text-yellow-400 border-yellow-400">
              {hero.skillPoints} SP
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-3">
          {/* Health and Mana */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-red-500" />
              <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-red-500 transition-all duration-300"
                  style={{ width: `${healthPercent}%` }}
                />
              </div>
              <span className="text-xs">{hero.health}/{hero.maxHealth}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-500" />
              <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-500 transition-all duration-300"
                  style={{ width: `${manaPercent}%` }}
                />
              </div>
              <span className="text-xs">{hero.mana}/{hero.maxMana}</span>
            </div>
          </div>

          {/* Experience */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span>Experience</span>
              <span>{hero.experience}/{hero.level * 100}</span>
            </div>
            <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-purple-500 transition-all duration-300"
                style={{ width: `${expProgress}%` }}
              />
            </div>
          </div>

          {/* Skills */}
          <div>
            <div className="text-sm font-semibold mb-2">Skills</div>
            <div className="grid grid-cols-1 gap-1">
              {Object.values(hero.skills).map((skill) => (
                <Button
                  key={skill.id}
                  onClick={() => unlockSkill(skill.id)}
                  disabled={skill.unlocked || hero.skillPoints < skill.cost || 
                    (skill.prereq && !hero.skills[skill.prereq]?.unlocked)}
                  size="sm"
                  variant={skill.unlocked ? "default" : "outline"}
                  className={`text-xs p-2 h-auto ${
                    skill.unlocked 
                      ? "bg-purple-600 hover:bg-purple-700" 
                      : "bg-gray-800 hover:bg-gray-700"
                  }`}
                >
                  <div className="text-left w-full">
                    <div className="font-semibold">{skill.name} ({skill.cost} SP)</div>
                    <div className="text-xs opacity-75">{skill.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}