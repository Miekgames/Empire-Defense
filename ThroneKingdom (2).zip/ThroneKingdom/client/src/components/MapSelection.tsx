import { useGameState, MapInfo, BiomeType } from "../lib/stores/useGameState";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Crown, Lock, CheckCircle, Mountain, TreePine, Flame, Droplets, Leaf } from "lucide-react";

const BiomeIcons: Record<BiomeType, React.ComponentType<any>> = {
  grasslands: Leaf,
  desert: Mountain,
  winter: TreePine,
  volcanic: Flame,
  swamp: Droplets
};

const BiomeColors: Record<BiomeType, string> = {
  grasslands: "bg-green-100 border-green-300",
  desert: "bg-yellow-100 border-yellow-300",
  winter: "bg-blue-100 border-blue-300",
  volcanic: "bg-red-100 border-red-300",
  swamp: "bg-purple-100 border-purple-300"
};

export default function MapSelection() {
  const { maps, currentMapId, selectMap, phase } = useGameState();

  if (phase !== "mapComplete") return null;

  const handleMapSelect = (mapId: string) => {
    selectMap(mapId);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto m-4">
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Crown className="w-8 h-8 text-yellow-500" />
            <h2 className="text-3xl font-bold text-gray-800">Kingdom Conquered!</h2>
          </div>
          <p className="text-gray-600">
            You have successfully defended your realm. Choose your next conquest:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {maps.map((map) => {
            const IconComponent = BiomeIcons[map.biome];
            const isLocked = !map.unlocked;
            const isCompleted = map.completed;
            const isCurrent = map.id === currentMapId;

            return (
              <Card 
                key={map.id} 
                className={`relative transition-all hover:shadow-lg ${
                  isLocked ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:scale-105'
                } ${BiomeColors[map.biome]} ${isCurrent ? 'ring-2 ring-blue-500' : ''}`}
                onClick={() => !isLocked && handleMapSelect(map.id)}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <IconComponent className="w-6 h-6" />
                      <CardTitle className="text-lg">{map.name}</CardTitle>
                    </div>
                    <div className="flex gap-1">
                      {isCompleted && <CheckCircle className="w-5 h-5 text-green-500" />}
                      {isLocked && <Lock className="w-5 h-5 text-gray-400" />}
                    </div>
                  </div>
                  <CardDescription className="text-sm">
                    {map.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="pt-2">
                  <div className="flex items-center justify-between mb-3">
                    <Badge variant="outline" className="text-xs">
                      {map.maxWaves} Waves
                    </Badge>
                    <Badge 
                      variant={map.biome === 'grasslands' ? 'default' : 'secondary'}
                      className="text-xs capitalize"
                    >
                      {map.biome}
                    </Badge>
                  </div>
                  
                  {!isLocked && (
                    <Button 
                      className="w-full" 
                      variant={isCurrent ? "default" : "outline"}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMapSelect(map.id);
                      }}
                    >
                      {isCurrent ? "Current Map" : isCompleted ? "Replay" : "Select"}
                    </Button>
                  )}
                  
                  {isLocked && (
                    <div className="text-center text-sm text-gray-500">
                      Complete previous maps to unlock
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500">
            Each biome presents unique challenges and enemy types
          </p>
        </div>
      </div>
    </div>
  );
}