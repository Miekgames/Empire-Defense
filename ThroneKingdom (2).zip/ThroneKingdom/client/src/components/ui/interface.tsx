// Interface component disabled to prevent UI conflicts
export function Interface() {
  return null;
}