
import { useState } from "react";
import { useEmpire, ResourceType, TechnologyType } from "../lib/stores/useEmpire";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { 
  Building2, 
  Coins, 
  Users, 
  Zap, 
  TreePine, 
  Mountain, 
  Wheat, 
  FlaskConical,
  Crown,
  Swords,
  Shield,
  Clock,
  TrendingUp,
  Home,
  Hammer,
  BookOpen,
  Globe
} from "lucide-react";

const ResourceIcons: Record<ResourceType, React.ComponentType<any>> = {
  food: Wheat,
  wood: TreePine,
  stone: Mountain,
  gold: Coins,
  power: Zap
};

const TechIcons: Record<TechnologyType, React.ComponentType<any>> = {
  agriculture: Wheat,
  construction: Building2,
  military: Swords,
  research: FlaskConical,
  economy: Coins
};

const CityManagement = () => {
  const [activeTab, setActiveTab] = useState("overview");
  
  const {
    resources,
    resourceCaps,
    population,
    maxPopulation,
    happiness,
    cityBuildings,
    technologies,
    troops,
    armyPower,
    currentAlliance,
    canAffordResources,
    upgradeBuilding,
    startResearch
  } = useEmpire();

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) return `${hours}h ${minutes}m`;
    if (minutes > 0) return `${minutes}m ${secs}s`;
    return `${secs}s`;
  };

  const getResourceColor = (current: number, cap: number) => {
    const percentage = (current / cap) * 100;
    if (percentage >= 90) return "text-red-500";
    if (percentage >= 70) return "text-yellow-500";
    return "text-green-500";
  };

  return (
    <div className="fixed top-4 left-96 w-96 max-h-[90vh] overflow-y-auto pointer-events-auto">
      <Card className="bg-black/90 text-white border-blue-500">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Crown className="w-6 h-6 text-yellow-500" />
            <CardTitle className="text-lg">Empire Management</CardTitle>
          </div>
        </CardHeader>
        
        <CardContent className="p-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="overview" className="text-xs">
                <Home className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="buildings" className="text-xs">
                <Building2 className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="research" className="text-xs">
                <BookOpen className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="military" className="text-xs">
                <Swords className="w-4 h-4" />
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 mt-4">
              {/* Resources */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-blue-400">Resources</h3>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(resources).map(([type, amount]) => {
                    const IconComponent = ResourceIcons[type as ResourceType];
                    const cap = resourceCaps[type as ResourceType];
                    const colorClass = getResourceColor(amount, cap);
                    
                    return (
                      <div key={type} className="flex items-center gap-2 bg-gray-800 p-2 rounded">
                        <IconComponent className="w-4 h-4 text-yellow-500" />
                        <div className="flex-1 min-w-0">
                          <div className={`text-xs font-mono ${colorClass}`}>
                            {Math.floor(amount)}/{cap}
                          </div>
                          <div className="text-xs text-gray-400 capitalize">{type}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Population & Happiness */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-blue-400">City Status</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">Population</span>
                    </div>
                    <span className="text-sm font-mono">{population}/{maxPopulation}</span>
                  </div>
                  <Progress value={(population / maxPopulation) * 100} className="h-2" />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-yellow-500">😊</span>
                      <span className="text-sm">Happiness</span>
                    </div>
                    <span className="text-sm font-mono">{happiness}%</span>
                  </div>
                  <Progress value={happiness} className="h-2" />
                </div>
              </div>

              {/* Alliance */}
              {currentAlliance ? (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold text-blue-400">Alliance</h3>
                  <div className="bg-gray-800 p-2 rounded">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-purple-500" />
                      <span className="text-sm font-medium">{currentAlliance.name}</span>
                    </div>
                    <div className="text-xs text-gray-400">
                      {currentAlliance.members.length} members • {currentAlliance.power} power
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold text-blue-400">Alliance</h3>
                  <Button variant="outline" size="sm" className="w-full">
                    Join Alliance
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="buildings" className="space-y-4 mt-4">
              <h3 className="text-sm font-semibold text-blue-400">City Buildings</h3>
              <div className="space-y-2">
                {cityBuildings.map((building) => (
                  <Card key={building.id} className="bg-gray-800 border-gray-600">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-blue-500" />
                          <span className="text-sm font-medium">{building.name}</span>
                          <Badge variant="outline" className="text-xs">
                            Lv.{building.level}
                          </Badge>
                        </div>
                        {building.isUpgrading && (
                          <Badge variant="secondary" className="text-xs">
                            <Clock className="w-3 h-3 mr-1" />
                            {formatTime(building.upgradeTimeRemaining)}
                          </Badge>
                        )}
                      </div>
                      
                      {building.isUpgrading ? (
                        <Progress 
                          value={((building.upgradeTime - building.upgradeTimeRemaining) / building.upgradeTime) * 100}
                          className="h-2"
                        />
                      ) : (
                        <div className="space-y-2">
                          <div className="text-xs text-gray-400">
                            Production: {Object.entries(building.productionRate)
                              .filter(([_, rate]) => rate > 0)
                              .map(([resource, rate]) => `${rate}/min ${resource}`)
                              .join(", ") || "None"}
                          </div>
                          
                          {building.level < building.maxLevel && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full text-xs"
                              onClick={() => upgradeBuilding(building.id)}
                              disabled={!canAffordResources(building.upgradeCost)}
                            >
                              <TrendingUp className="w-3 h-3 mr-1" />
                              Upgrade ({formatTime(building.upgradeTime)})
                            </Button>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="research" className="space-y-4 mt-4">
              <h3 className="text-sm font-semibold text-blue-400">Technology Research</h3>
              <div className="space-y-2">
                {technologies.map((tech) => {
                  const IconComponent = TechIcons[tech.type];
                  const canResearch = tech.unlocked && !tech.researching && canAffordResources(tech.cost);
                  
                  return (
                    <Card key={tech.id} className={`bg-gray-800 border-gray-600 ${!tech.unlocked ? 'opacity-50' : ''}`}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <IconComponent className="w-4 h-4 text-purple-500" />
                            <span className="text-sm font-medium">{tech.name}</span>
                          </div>
                          {tech.researching && (
                            <Badge variant="secondary" className="text-xs">
                              <Clock className="w-3 h-3 mr-1" />
                              {formatTime(tech.timeRemaining)}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="text-xs text-gray-400 mb-2">{tech.description}</div>
                        
                        {tech.researching ? (
                          <Progress 
                            value={((tech.researchTime - tech.timeRemaining) / tech.researchTime) * 100}
                            className="h-2"
                          />
                        ) : (
                          tech.unlocked && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full text-xs"
                              onClick={() => startResearch(tech.id)}
                              disabled={!canResearch}
                            >
                              <FlaskConical className="w-3 h-3 mr-1" />
                              Research ({formatTime(tech.researchTime)})
                            </Button>
                          )
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="military" className="space-y-4 mt-4">
              <h3 className="text-sm font-semibold text-blue-400">Military Forces</h3>
              
              <div className="bg-gray-800 p-3 rounded">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Swords className="w-4 h-4 text-red-500" />
                    <span className="text-sm font-medium">Army Power</span>
                  </div>
                  <span className="text-sm font-mono text-red-500">{armyPower.toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-gray-400">Troops</h4>
                {Object.entries(troops).map(([type, count]) => (
                  <div key={type} className="flex items-center justify-between bg-gray-800 p-2 rounded">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-blue-500" />
                      <span className="text-sm capitalize">{type}</span>
                    </div>
                    <span className="text-sm font-mono">{count}</span>
                  </div>
                ))}
              </div>

              <Button variant="outline" className="w-full">
                <Hammer className="w-4 h-4 mr-2" />
                Train Troops
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default CityManagement;
