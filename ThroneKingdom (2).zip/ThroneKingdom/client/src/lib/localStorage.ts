// Local storage utilities for client-only game state
export const STORAGE_KEYS = {
  GAME_SAVE: 'empire-defense-save',
  SETTINGS: 'empire-defense-settings',
  HIGH_SCORES: 'empire-defense-scores'
};

export interface GameSave {
  wave: number;
  resources: Record<string, number>;
  buildings: any[];
  empire: any;
  timestamp: number;
}

export const saveGame = (data: GameSave) => {
  try {
    localStorage.setItem(STORAGE_KEYS.GAME_SAVE, JSON.stringify(data));
  } catch (error) {
    console.warn('Failed to save game data:', error);
  }
};

export const loadGame = (): GameSave | null => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.GAME_SAVE);
    return saved ? JSON.parse(saved) : null;
  } catch (error) {
    console.warn('Failed to load game data:', error);
    return null;
  }
};

export const clearSave = () => {
  localStorage.removeItem(STORAGE_KEYS.GAME_SAVE);
};

export const saveSettings = (settings: any) => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (error) {
    console.warn('Failed to save settings:', error);
  }
};

export const loadSettings = () => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : { volume: 0.5, graphics: 'medium' };
  } catch (error) {
    console.warn('Failed to load settings:', error);
    return { volume: 0.5, graphics: 'medium' };
  }
};