// Simple A* pathfinding implementation for enemies

interface Node {
  x: number;
  z: number;
  g: number; // Cost from start
  h: number; // Heuristic cost to goal
  f: number; // Total cost
  parent: Node | null;
}

export function findPath(
  start: { x: number; z: number },
  goal: { x: number; z: number },
  obstacles: { x: number; z: number }[]
): { x: number; z: number }[] {
  const openSet: Node[] = [];
  const closedSet: Node[] = [];
  
  const startNode: Node = {
    x: Math.round(start.x),
    z: Math.round(start.z),
    g: 0,
    h: heuristic(start, goal),
    f: 0,
    parent: null
  };
  startNode.f = startNode.g + startNode.h;
  
  openSet.push(startNode);
  
  while (openSet.length > 0) {
    // Find node with lowest f score
    let currentIndex = 0;
    for (let i = 1; i < openSet.length; i++) {
      if (openSet[i].f < openSet[currentIndex].f) {
        currentIndex = i;
      }
    }
    
    const current = openSet.splice(currentIndex, 1)[0];
    closedSet.push(current);
    
    // Check if we reached the goal
    if (Math.abs(current.x - Math.round(goal.x)) <= 1 && 
        Math.abs(current.z - Math.round(goal.z)) <= 1) {
      return reconstructPath(current);
    }
    
    // Check neighbors
    const neighbors = getNeighbors(current);
    
    for (const neighbor of neighbors) {
      if (closedSet.find(n => n.x === neighbor.x && n.z === neighbor.z)) {
        continue;
      }
      
      // Check if neighbor is an obstacle
      if (obstacles.find(obs => Math.abs(obs.x - neighbor.x) < 0.5 && Math.abs(obs.z - neighbor.z) < 0.5)) {
        continue;
      }
      
      const tentativeG = current.g + 1;
      
      const existingNode = openSet.find(n => n.x === neighbor.x && n.z === neighbor.z);
      
      if (!existingNode) {
        neighbor.g = tentativeG;
        neighbor.h = heuristic(neighbor, goal);
        neighbor.f = neighbor.g + neighbor.h;
        neighbor.parent = current;
        openSet.push(neighbor);
      } else if (tentativeG < existingNode.g) {
        existingNode.g = tentativeG;
        existingNode.f = existingNode.g + existingNode.h;
        existingNode.parent = current;
      }
    }
  }
  
  // No path found, return direct path
  return [start, goal];
}

function heuristic(a: { x: number; z: number }, b: { x: number; z: number }): number {
  return Math.abs(a.x - b.x) + Math.abs(a.z - b.z);
}

function getNeighbors(node: Node): Node[] {
  const neighbors: Node[] = [];
  const directions = [
    { x: 0, z: 1 }, { x: 1, z: 0 }, { x: 0, z: -1 }, { x: -1, z: 0 },
    { x: 1, z: 1 }, { x: 1, z: -1 }, { x: -1, z: 1 }, { x: -1, z: -1 }
  ];
  
  for (const dir of directions) {
    const newX = node.x + dir.x;
    const newZ = node.z + dir.z;
    
    // Keep within reasonable bounds
    if (newX >= -10 && newX <= 10 && newZ >= -10 && newZ <= 10) {
      neighbors.push({
        x: newX,
        z: newZ,
        g: 0,
        h: 0,
        f: 0,
        parent: null
      });
    }
  }
  
  return neighbors;
}

function reconstructPath(node: Node): { x: number; z: number }[] {
  const path: { x: number; z: number }[] = [];
  let current: Node | null = node;
  
  while (current) {
    path.unshift({ x: current.x, z: current.z });
    current = current.parent;
  }
  
  return path;
}
