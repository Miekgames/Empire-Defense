import { create } from "zustand";

export type QuestType = "rescue_caravan" | "escort_merchant" | "hunt_bandit" | "defend_outpost";

export interface Quest {
  id: string;
  type: QuestType;
  name: string;
  description: string;
  objectives: string[];
  progress: number;
  maxProgress: number;
  timeLimit?: number;
  timeRemaining?: number;
  rewards: {
    gold: number;
    materials?: { type: string; amount: number }[];
    blueprints?: string[];
  };
  isActive: boolean;
  isCompleted: boolean;
  difficulty: "easy" | "medium" | "hard";
}

interface QuestState {
  activeQuests: Quest[];
  completedQuests: Quest[];
  availableQuests: Quest[];
  
  generateRandomQuest: () => void;
  acceptQuest: (questId: string) => void;
  updateQuestProgress: (questId: string, progress: number) => void;
  completeQuest: (questId: string) => Quest | null;
  updateQuestTimers: (deltaTime: number) => void;
  resetQuests: () => void;
}

const questTemplates: Record<QuestType, Omit<Quest, 'id' | 'progress' | 'timeRemaining' | 'isActive' | 'isCompleted'>> = {
  rescue_caravan: {
    type: "rescue_caravan",
    name: "Rescue the Lost Caravan",
    description: "A merchant caravan is under siege by bandits. Save them before it's too late!",
    objectives: ["Defeat 20 enemies within 3 minutes"],
    maxProgress: 20,
    timeLimit: 180,
    rewards: {
      gold: 150,
      materials: [{ type: "wood", amount: 10 }],
      blueprints: ["reinforced_wall"]
    },
    difficulty: "medium"
  },
  escort_merchant: {
    type: "escort_merchant",
    name: "Merchant Escort",
    description: "Escort a wealthy merchant safely through dangerous territory.",
    objectives: ["Protect the merchant for 5 waves"],
    maxProgress: 5,
    rewards: {
      gold: 200,
      materials: [{ type: "metal", amount: 8 }]
    },
    difficulty: "hard"
  },
  hunt_bandit: {
    type: "hunt_bandit",
    name: "Bandit Hunter",
    description: "Track down and eliminate the bandit leader terrorizing local villages.",
    objectives: ["Defeat the bandit boss"],
    maxProgress: 1,
    rewards: {
      gold: 300,
      materials: [{ type: "essence", amount: 15 }],
      blueprints: ["bandit_tracker"]
    },
    difficulty: "hard"
  },
  defend_outpost: {
    type: "defend_outpost",
    name: "Outpost Defense",
    description: "Help defend a remote outpost from incoming raiders.",
    objectives: ["Survive 3 waves without losing any buildings"],
    maxProgress: 3,
    timeLimit: 300,
    rewards: {
      gold: 100,
      materials: [{ type: "stone", amount: 12 }]
    },
    difficulty: "easy"
  }
};

export const useQuests = create<QuestState>((set, get) => ({
  activeQuests: [],
  completedQuests: [],
  availableQuests: [],

  generateRandomQuest: () => {
    const types = Object.keys(questTemplates) as QuestType[];
    const randomType = types[Math.floor(Math.random() * types.length)];
    const template = questTemplates[randomType];
    
    const newQuest: Quest = {
      ...template,
      id: `quest-${randomType}-${Date.now()}`,
      progress: 0,
      timeRemaining: template.timeLimit,
      isActive: false,
      isCompleted: false
    };
    
    set(state => ({
      availableQuests: [...state.availableQuests.filter(q => q.type !== randomType), newQuest]
    }));
  },

  acceptQuest: (questId) => {
    set(state => {
      const quest = state.availableQuests.find(q => q.id === questId);
      if (!quest) return state;
      
      return {
        availableQuests: state.availableQuests.filter(q => q.id !== questId),
        activeQuests: [...state.activeQuests, { ...quest, isActive: true }]
      };
    });
  },

  updateQuestProgress: (questId, progress) => {
    set(state => ({
      activeQuests: state.activeQuests.map(quest =>
        quest.id === questId
          ? { ...quest, progress: Math.min(progress, quest.maxProgress) }
          : quest
      )
    }));
  },

  completeQuest: (questId) => {
    const state = get();
    const quest = state.activeQuests.find(q => q.id === questId);
    
    if (!quest || quest.progress < quest.maxProgress) {
      return null;
    }
    
    set(state => ({
      activeQuests: state.activeQuests.filter(q => q.id !== questId),
      completedQuests: [...state.completedQuests, { ...quest, isCompleted: true }]
    }));
    
    return quest;
  },

  updateQuestTimers: (deltaTime) => {
    set(state => ({
      activeQuests: state.activeQuests.map(quest => {
        if (!quest.timeLimit || !quest.timeRemaining) return quest;
        
        const newTimeRemaining = Math.max(0, quest.timeRemaining - deltaTime);
        return { ...quest, timeRemaining: newTimeRemaining };
      }).filter(quest => !quest.timeLimit || (quest.timeRemaining && quest.timeRemaining > 0))
    }));
  },

  resetQuests: () => {
    set({
      activeQuests: [],
      completedQuests: [],
      availableQuests: []
    });
  }
}));