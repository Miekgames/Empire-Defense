import { create } from "zustand";
import { useResources } from "./useResources";
import { useEmpire } from "./useEmpire";

export type BuildingType = "tower" | "wall" | "house" | "barracks" | "throne" | "forge" | "market" | "temple" | "watchtower" | "gatehouse" | "farm" | "lumbermill" | "quarry" | "goldmine" | "powerplant";

export interface BuildingUpgrade {
  level: number;
  cost: number;
  healthBonus: number;
  damageBonus?: number;
  rangeBonus?: number;
  specialAbility?: string;
}

export interface Building {
  id: string;
  type: BuildingType;
  x: number;
  z: number;
  health: number;
  maxHealth: number;
  level: number;
  lastAttack: number;
  upgrades: BuildingUpgrade[];
  isUpgrading: boolean;
  upgradeTimeRemaining: number;
  garrison?: number; // For barracks
  production?: number; // For houses/markets
  resourceType?: "food" | "wood" | "stone" | "gold" | "power"; // For resource buildings
  productionRate?: number; // Resources per second
  lastProduction?: number; // Last production timestamp
}

interface BuildingsState {
  buildings: Building[];
  selectedBuildingType: BuildingType | null;
  
  setSelectedBuildingType: (type: BuildingType | null) => void;
  placeBuilding: (x: number, z: number, type: BuildingType) => void;
  isValidPlacement: (x: number, z: number, type: BuildingType) => boolean;
  canAffordBuilding: (type: BuildingType) => boolean;
  damageBuilding: (id: string, damage: number) => void;
  removeBuilding: (id: string) => void;
  resetBuildings: () => void;
  upgradeBuilding: (id: string) => boolean;
  updateUpgrades: (deltaTime: number) => void;
  updateResourceProduction: (deltaTime: number) => void;
  getBuildingStats: (building: Building) => {
    damage: number;
    range: number;
    health: number;
  };
}

const buildingCosts = {
  tower: 50,
  wall: 25,
  house: 75,
  barracks: 100,
  throne: 0,
  forge: 120,
  market: 90,
  temple: 150,
  watchtower: 80,
  gatehouse: 200,
  farm: 60,
  lumbermill: 70,
  quarry: 80,
  goldmine: 100,
  powerplant: 150
};

const buildingHealth = {
  tower: 100,
  wall: 150,
  house: 75,
  barracks: 125,
  throne: 200,
  forge: 90,
  market: 70,
  temple: 110,
  watchtower: 130,
  gatehouse: 250,
  farm: 60,
  lumbermill: 80,
  quarry: 100,
  goldmine: 90,
  powerplant: 120
};

export const useBuildings = create<BuildingsState>((set, get) => ({
  buildings: [
    // Start with a throne in the center
    {
      id: "throne",
      type: "throne",
      x: 0,
      z: 0,
      health: 200,
      maxHealth: 200,
      level: 1,
      lastAttack: 0,
      upgrades: [],
      isUpgrading: false,
      upgradeTimeRemaining: 0
    }
  ],
  selectedBuildingType: null,
  
  setSelectedBuildingType: (type) => set({ selectedBuildingType: type }),
  
  placeBuilding: (x, z, type) => {
    const { buildings, isValidPlacement, canAffordBuilding } = get();
    
    if (!isValidPlacement(x, z, type) || !canAffordBuilding(type)) return;
    
    // Configure resource production for new buildings
    const resourceBuildings = {
      farm: { resourceType: "food" as const, productionRate: 2 },
      lumbermill: { resourceType: "wood" as const, productionRate: 1.5 },
      quarry: { resourceType: "stone" as const, productionRate: 1 },
      goldmine: { resourceType: "gold" as const, productionRate: 0.5 },
      powerplant: { resourceType: "power" as const, productionRate: 0.3 }
    };

    const newBuilding: Building = {
      id: `${type}-${Date.now()}-${Math.random()}`,
      type,
      x,
      z,
      health: buildingHealth[type],
      maxHealth: buildingHealth[type],
      level: 1,
      lastAttack: 0,
      upgrades: [],
      isUpgrading: false,
      upgradeTimeRemaining: 0,
      garrison: type === 'barracks' ? 0 : undefined,
      production: type === 'house' || type === 'market' ? 1 : undefined,
      resourceType: resourceBuildings[type as keyof typeof resourceBuildings]?.resourceType,
      productionRate: resourceBuildings[type as keyof typeof resourceBuildings]?.productionRate,
      lastProduction: Date.now()
    };
    
    set({ buildings: [...buildings, newBuilding] });
    
    // Deduct cost
    useResources.getState().spendGold(buildingCosts[type]);
  },
  
  isValidPlacement: (x, z, type) => {
    const { buildings } = get();
    
    // Check if position is occupied
    const occupied = buildings.some(building => 
      Math.abs(building.x - x) < 0.5 && Math.abs(building.z - z) < 0.5
    );
    
    return !occupied;
  },
  
  canAffordBuilding: (type) => {
    const cost = buildingCosts[type];
    const gold = useResources.getState().gold;
    return gold >= cost;
  },
  
  damageBuilding: (id, damage) => {
    set(state => ({
      buildings: state.buildings.map(building =>
        building.id === id
          ? { ...building, health: Math.max(0, building.health - damage) }
          : building
      )
    }));
  },
  
  removeBuilding: (id) => {
    set(state => ({
      buildings: state.buildings.filter(building => building.id !== id)
    }));
  },
  
  resetBuildings: () => {
    set({
      buildings: [
        {
          id: "throne",
          type: "throne",
          x: 0,
          z: 0,
          health: 200,
          maxHealth: 200,
          level: 1,
          lastAttack: 0,
          upgrades: [],
          isUpgrading: false,
          upgradeTimeRemaining: 0
        }
      ],
      selectedBuildingType: null
    });
  },

  upgradeBuilding: (id) => {
    const state = get();
    const building = state.buildings.find(b => b.id === id);
    const upgradeCost = 50 * building!.level;
    
    if (!building || building.isUpgrading || useResources.getState().gold < upgradeCost) {
      return false;
    }
    
    useResources.getState().spendGold(upgradeCost);
    
    set(state => ({
      buildings: state.buildings.map(b =>
        b.id === id
          ? { ...b, isUpgrading: true, upgradeTimeRemaining: 10 }
          : b
      )
    }));
    
    return true;
  },

  updateUpgrades: (deltaTime) => {
    set(state => ({
      buildings: state.buildings.map(building => {
        if (!building.isUpgrading) return building;
        
        const newTimeRemaining = Math.max(0, building.upgradeTimeRemaining - deltaTime);
        
        if (newTimeRemaining === 0) {
          return {
            ...building,
            level: building.level + 1,
            maxHealth: building.maxHealth + 50,
            health: building.health + 50,
            isUpgrading: false,
            upgradeTimeRemaining: 0
          };
        }
        
        return { ...building, upgradeTimeRemaining: newTimeRemaining };
      })
    }));
  },

  updateResourceProduction: (deltaTime) => {
    const { buildings } = get();
    const currentTime = Date.now();
    
    buildings.forEach(building => {
      if (building.resourceType && building.productionRate && building.lastProduction) {
        const timeSinceLastProduction = (currentTime - building.lastProduction) / 1000;
        
        if (timeSinceLastProduction >= 1) { // Produce every second
          const resourceAmount = building.productionRate * building.level; // Scale with level
          
          // Add resources to empire store
          useEmpire.getState().addResource(building.resourceType, resourceAmount);
          
          // Update last production time
          set(state => ({
            buildings: state.buildings.map(b =>
              b.id === building.id
                ? { ...b, lastProduction: currentTime }
                : b
            )
          }));
        }
      }
    });
  },

  getBuildingStats: (building) => {
    const baseDamage = building.type === 'tower' ? 25 : building.type === 'watchtower' ? 35 : 0;
    const baseRange = building.type === 'tower' ? 3 : building.type === 'watchtower' ? 4 : 0;
    
    return {
      damage: baseDamage + (building.level - 1) * 10,
      range: baseRange + (building.level - 1) * 0.5,
      health: building.health
    };
  }
}));
