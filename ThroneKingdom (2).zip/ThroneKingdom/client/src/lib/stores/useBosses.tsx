import { create } from "zustand";

export type BossType = "siege_ram" | "wyvern" | "giant_ogre" | "catapult_squad";

export interface Boss {
  id: string;
  type: BossType;
  name: string;
  x: number;
  z: number;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  gold: number;
  abilities: string[];
  weaknesses: string[];
  isFlying: boolean;
  size: number;
  lastAbilityUse: number;
}

interface BossState {
  activeBosses: Boss[];
  bossWaveScheduled: boolean;
  nextBossWave: number;
  
  spawnBoss: (type: BossType, x: number, z: number) => void;
  damageBoss: (id: string, damage: number) => void;
  removeBoss: (id: string) => void;
  clearBosses: () => void;
  scheduleBossWave: (wave: number) => void;
  shouldSpawnBoss: (currentWave: number) => boolean;
}

const bossTemplates: Record<BossType, Omit<Boss, 'id' | 'x' | 'z' | 'lastAbilityUse'>> = {
  siege_ram: {
    type: "siege_ram",
    name: "Ancient Siege Ram",
    health: 800,
    maxHealth: 800,
    speed: 0.5,
    damage: 100,
    gold: 200,
    abilities: ["ram_charge", "armor_plating"],
    weaknesses: ["fire"],
    isFlying: false,
    size: 2
  },
  wyvern: {
    type: "wyvern",
    name: "Shadow Wyvern",
    health: 600,
    maxHealth: 600,
    speed: 1.2,
    damage: 80,
    gold: 250,
    abilities: ["aerial_dive", "fire_breath"],
    weaknesses: ["ranged"],
    isFlying: true,
    size: 1.8
  },
  giant_ogre: {
    type: "giant_ogre",
    name: "Ogre Chieftain",
    health: 1200,
    maxHealth: 1200,
    speed: 0.6,
    damage: 120,
    gold: 300,
    abilities: ["ground_slam", "rage_mode"],
    weaknesses: ["magic"],
    isFlying: false,
    size: 2.5
  },
  catapult_squad: {
    type: "catapult_squad",
    name: "Siege Artillery",
    health: 400,
    maxHealth: 400,
    speed: 0.3,
    damage: 150,
    gold: 180,
    abilities: ["long_range_shot", "area_bombardment"],
    weaknesses: ["melee"],
    isFlying: false,
    size: 1.5
  }
};

export const useBosses = create<BossState>((set, get) => ({
  activeBosses: [],
  bossWaveScheduled: false,
  nextBossWave: 5,

  spawnBoss: (type, x, z) => {
    const template = bossTemplates[type];
    const newBoss: Boss = {
      ...template,
      id: `${type}-${Date.now()}-${Math.random()}`,
      x,
      z,
      lastAbilityUse: 0
    };
    
    set(state => ({ 
      activeBosses: [...state.activeBosses, newBoss] 
    }));
  },

  damageBoss: (id, damage) => {
    set(state => ({
      activeBosses: state.activeBosses.map(boss =>
        boss.id === id
          ? { ...boss, health: Math.max(0, boss.health - damage) }
          : boss
      )
    }));
  },

  removeBoss: (id) => {
    set(state => ({
      activeBosses: state.activeBosses.filter(boss => boss.id !== id)
    }));
  },

  clearBosses: () => {
    set({ activeBosses: [] });
  },

  scheduleBossWave: (wave) => {
    set({ nextBossWave: wave + 5, bossWaveScheduled: true });
  },

  shouldSpawnBoss: (currentWave) => {
    const state = get();
    return currentWave >= state.nextBossWave && currentWave % 5 === 0;
  }
}));