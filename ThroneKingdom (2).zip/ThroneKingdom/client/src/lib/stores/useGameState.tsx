import { create } from "zustand";

export type GamePhase = "building" | "wave" | "victory" | "gameOver" | "mapComplete";
export type BiomeType = "grasslands" | "desert" | "winter" | "volcanic" | "swamp";

export interface MapInfo {
  id: string;
  name: string;
  biome: BiomeType;
  maxWaves: number;
  description: string;
  unlocked: boolean;
  completed: boolean;
}

interface GameState {
  phase: GamePhase;
  currentWave: number;
  waveProgress: number;
  maxWaves: number;
  currentMapId: string;
  maps: MapInfo[];
  
  startWave: () => void;
  endWave: (success: boolean) => void;
  resetGame: () => void;
  setWaveProgress: (progress: number) => void;
  completeMap: () => void;
  selectMap: (mapId: string) => void;
  unlockNextMap: () => void;
}

const initialMaps: MapInfo[] = [
  {
    id: "grasslands",
    name: "Green Meadows",
    biome: "grasslands",
    maxWaves: 20,
    description: "Peaceful grasslands where your kingdom begins",
    unlocked: true,
    completed: false
  },
  {
    id: "desert",
    name: "Scorching Sands",
    biome: "desert",
    maxWaves: 25,
    description: "Harsh desert with sandstorms and mirages",
    unlocked: false,
    completed: false
  },
  {
    id: "winter",
    name: "Frozen Tundra",
    biome: "winter",
    maxWaves: 30,
    description: "Ice-covered lands with blizzards and frost giants",
    unlocked: false,
    completed: false
  },
  {
    id: "volcanic",
    name: "Molten Peaks",
    biome: "volcanic",
    maxWaves: 35,
    description: "Volcanic landscape with lava flows and fire demons",
    unlocked: false,
    completed: false
  },
  {
    id: "swamp",
    name: "Cursed Marshlands",
    biome: "swamp",
    maxWaves: 40,
    description: "Dark swamps filled with poisonous creatures",
    unlocked: false,
    completed: false
  }
];

export const useGameState = create<GameState>((set, get) => ({
  phase: "building",
  currentWave: 1,
  waveProgress: 0,
  maxWaves: 20,
  currentMapId: "grasslands",
  maps: initialMaps,
  
  startWave: () => {
    set({ phase: "wave", waveProgress: 0 });
  },
  
  endWave: (success: boolean) => {
    const { currentWave, maxWaves } = get();
    
    if (!success) {
      set({ phase: "gameOver" });
    } else if (currentWave >= maxWaves) {
      set({ phase: "mapComplete" });
      get().completeMap();
    } else {
      set({ 
        phase: "building", 
        currentWave: currentWave + 1,
        waveProgress: 0 
      });
    }
  },
  
  resetGame: () => {
    set({ 
      phase: "building", 
      currentWave: 1, 
      waveProgress: 0 
    });
  },
  
  setWaveProgress: (progress: number) => {
    set({ waveProgress: progress });
  },

  completeMap: () => {
    set(state => ({
      maps: state.maps.map(map =>
        map.id === state.currentMapId
          ? { ...map, completed: true }
          : map
      )
    }));
    get().unlockNextMap();
  },

  selectMap: (mapId) => {
    const state = get();
    const selectedMap = state.maps.find(map => map.id === mapId);
    
    if (selectedMap && selectedMap.unlocked) {
      set({
        currentMapId: mapId,
        maxWaves: selectedMap.maxWaves,
        phase: "building",
        currentWave: 1,
        waveProgress: 0
      });
    }
  },

  unlockNextMap: () => {
    set(state => {
      const currentIndex = state.maps.findIndex(map => map.id === state.currentMapId);
      const nextIndex = currentIndex + 1;
      
      if (nextIndex < state.maps.length) {
        return {
          maps: state.maps.map((map, index) =>
            index === nextIndex
              ? { ...map, unlocked: true }
              : map
          )
        };
      }
      
      return state;
    });
  }
}));
