import { create } from "zustand";

export type EnemyType = "peasant" | "archer" | "swordsman" | "spearman" | "ogre" | "racer" | "exploder" | "wizard" | "berserker" | "giant" | "assassin" | "necromancer";

export interface Enemy {
  id: string;
  type: EnemyType;
  x: number;
  z: number;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  gold: number;
  target: { x: number; z: number } | null;
  path: { x: number; z: number }[];
  pathIndex: number;
  lastDamageTime: number;
  isGolden: boolean;
  behavior: "normal" | "rusher" | "exploder" | "slow";
}

interface EnemiesState {
  enemies: Enemy[];
  
  spawnEnemy: (type: EnemyType, x: number, z: number) => void;
  updateEnemies: (deltaTime: number) => void;
  damageEnemy: (id: string, damage: number) => void;
  removeEnemy: (id: string) => void;
  clearEnemies: () => void;
}

const enemyStats = {
  peasant: { health: 25, speed: 1.5, damage: 5, gold: 5, behavior: "normal" as const },
  archer: { health: 40, speed: 1.2, damage: 15, gold: 8, behavior: "normal" as const },
  swordsman: { health: 80, speed: 1.0, damage: 20, gold: 12, behavior: "normal" as const },
  spearman: { health: 60, speed: 1.3, damage: 12, gold: 10, behavior: "slow" as const },
  ogre: { health: 300, speed: 0.8, damage: 40, gold: 50, behavior: "normal" as const },
  racer: { health: 30, speed: 3.0, damage: 8, gold: 15, behavior: "rusher" as const },
  exploder: { health: 45, speed: 1.8, damage: 60, gold: 20, behavior: "exploder" as const },
  wizard: { health: 120, speed: 1.1, damage: 35, gold: 30, behavior: "normal" as const },
  berserker: { health: 200, speed: 2.2, damage: 45, gold: 40, behavior: "rusher" as const },
  giant: { health: 800, speed: 0.6, damage: 80, gold: 100, behavior: "slow" as const },
  assassin: { health: 75, speed: 2.8, damage: 25, gold: 35, behavior: "rusher" as const },
  necromancer: { health: 150, speed: 0.9, damage: 50, gold: 75, behavior: "normal" as const }
};

export const useEnemies = create<EnemiesState>((set, get) => ({
  enemies: [],
  
  spawnEnemy: (type, x, z) => {
    const stats = enemyStats[type];
    const isGolden = Math.random() < 0.1; // 10% chance for golden enemies
    const healthMultiplier = isGolden ? 2.5 : 1;
    const damageMultiplier = isGolden ? 2 : 1;
    
    const newEnemy: Enemy = {
      id: `${type}-${Date.now()}-${Math.random()}`,
      type,
      x,
      z,
      health: stats.health * healthMultiplier,
      maxHealth: stats.health * healthMultiplier,
      speed: stats.speed,
      damage: stats.damage * damageMultiplier,
      gold: stats.gold * (isGolden ? 3 : 1),
      target: { x: 0, z: 0 }, // Target the throne
      path: [],
      pathIndex: 0,
      lastDamageTime: 0,
      isGolden,
      behavior: stats.behavior
    };
    
    set(state => ({ enemies: [...state.enemies, newEnemy] }));
  },
  
  updateEnemies: (deltaTime) => {
    set(state => ({
      enemies: state.enemies.map(enemy => {
        if (!enemy.target) return enemy;
        
        // Simple movement towards target
        const dx = enemy.target.x - enemy.x;
        const dz = enemy.target.z - enemy.z;
        const distance = Math.sqrt(dx * dx + dz * dz);
        
        if (distance > 0.1) {
          let actualSpeed = enemy.speed;
          
          // Apply behavior modifiers
          if (enemy.behavior === "rusher") {
            actualSpeed *= 1.5; // Racers move faster toward throne
          } else if (enemy.behavior === "slow") {
            actualSpeed *= 0.7; // Spearmen slow down when attacking
          }
          
          const moveX = (dx / distance) * actualSpeed * deltaTime;
          const moveZ = (dz / distance) * actualSpeed * deltaTime;
          
          return {
            ...enemy,
            x: enemy.x + moveX,
            z: enemy.z + moveZ
          };
        }
        
        return enemy;
      })
    }));
  },
  
  damageEnemy: (id, damage) => {
    set(state => ({
      enemies: state.enemies.map(enemy =>
        enemy.id === id
          ? { ...enemy, health: Math.max(0, enemy.health - damage) }
          : enemy
      )
    }));
  },
  
  removeEnemy: (id) => {
    set(state => ({
      enemies: state.enemies.filter(enemy => enemy.id !== id)
    }));
  },
  
  clearEnemies: () => {
    set({ enemies: [] });
  }
}));
