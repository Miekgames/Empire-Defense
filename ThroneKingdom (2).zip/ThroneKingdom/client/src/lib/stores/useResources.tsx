import { create } from "zustand";

interface ResourcesState {
  gold: number;
  lives: number;
  
  addGold: (amount: number) => void;
  spendGold: (amount: number) => boolean;
  loseLives: (amount: number) => void;
  resetResources: () => void;
}

export const useResources = create<ResourcesState>((set, get) => ({
  gold: 200, // Starting gold
  lives: 5,  // Starting lives
  
  addGold: (amount) => {
    set(state => ({ gold: state.gold + amount }));
  },
  
  spendGold: (amount) => {
    const { gold } = get();
    if (gold >= amount) {
      set(state => ({ gold: state.gold - amount }));
      return true;
    }
    return false;
  },
  
  loseLives: (amount) => {
    set(state => ({ lives: Math.max(0, state.lives - amount) }));
  },
  
  resetResources: () => {
    set({ gold: 200, lives: 5 });
  }
}));
