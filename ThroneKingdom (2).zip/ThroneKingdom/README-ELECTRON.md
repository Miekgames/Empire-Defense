# Empire Defense - Standalone Executable Build Guide

This guide will help you create a standalone .exe file of your Empire Defense game that works on any Windows computer without requiring Node.js or any other dependencies.

## Quick Build Instructions

### Method 1: Automated Build Script (Recommended)
```bash
node build-electron.js
```

### Method 2: Windows Batch File
Double-click `build-exe.bat` or run:
```bash
build-exe.bat
```

### Method 3: Manual Step-by-Step
```bash
# Step 1: Build the web application
npm run build

# Step 2: Create the executable
npx electron-builder --config package-electron.json --win --x64
```

Your standalone executable will be created in the `electron-dist` folder.

## What You'll Get

- **Empire-Defense-Setup-X.X.X.exe** - An installer that creates a desktop shortcut
- **Portable version** - The app can also be run directly from the unpacked folder

## How It Works

The Electron build packages your game with:
- ✅ Chrome browser engine (for running the web game)
- ✅ Node.js runtime (embedded, not visible to users)
- ✅ Your complete game files
- ✅ All dependencies bundled inside

## File Sizes
- **Installer**: ~150-200 MB (includes everything needed)
- **Installed app**: ~300-400 MB (typical for Electron games)

## Distribution
Users can simply:
1. Download your .exe installer
2. Run the installer
3. Launch "Empire Defense" from their desktop or start menu
4. Play immediately - no other software needed!

## Development Mode
To test the Electron version during development:
```bash
# Start the web server
npm run dev

# In another terminal, start Electron
npx electron electron/main.js
```

## Troubleshooting
- If build fails, ensure you have at least 4GB free disk space
- Windows Defender might scan the .exe - this is normal for new executables
- The first build takes longer as it downloads the Electron runtime

## Technical Details
- **Framework**: Electron (packages web apps as desktop apps)
- **Target**: Windows x64 (can be configured for Mac/Linux too)
- **Architecture**: Web frontend + Express backend bundled together
- **Security**: Sandboxed with context isolation enabled