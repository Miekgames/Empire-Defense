# Deploy Empire Defense to GitHub Pages

## Step-by-Step Deployment Guide

### 1. Create GitHub Repository
1. Go to [GitHub.com](https://github.com) and sign in
2. Click "New repository" (green button)
3. Name it anything you want (e.g., "empire-defense-game", "my-strategy-game")
4. Make it **Public** (required for free GitHub Pages)
5. Don't initialize with README (we already have files)
6. Click "Create repository"

### 2. Upload Your Game Files
**Option A: Upload via Web Interface**
1. On your new repository page, click "uploading an existing file"
2. Drag and drop ALL your game files including:
   - All folders (.github, client, server, shared, etc.)
   - All files (package.json, README.md, etc.)
3. Scroll down, add commit message: "Initial game upload"
4. Click "Commit changes"

**Option B: Use Git Commands** (if you have Git installed)
```bash
git init
git add .
git commit -m "Initial game upload"
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
git branch -M main
git push -u origin main
```

### 3. Enable GitHub Pages
1. In your repository, click "Settings" tab
2. Scroll down to "Pages" in the left sidebar
3. Under "Source", select **"GitHub Actions"**
4. Click "Save"

### 4. Automatic Deployment
- The game will automatically build and deploy
- Check the "Actions" tab to see build progress
- First deployment takes 2-5 minutes
- Green checkmark = successful deployment

### 5. Access Your Game
Your game will be available at:
```
https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/
```

Example: `https://mike-games.github.io/empire-defense-game/`

## Troubleshooting

**Build Fails?**
- Check "Actions" tab for error details
- Ensure all files were uploaded properly
- Repository must be public for free GitHub Pages

**Game Doesn't Load?**
- Wait 5-10 minutes after first deployment
- Check browser console for errors (F12)
- Try hard refresh (Ctrl+F5)

**Updates Not Showing?**
- Changes take 1-2 minutes to deploy automatically
- Check Actions tab to confirm build completed

## Making Updates
1. Edit files directly on GitHub web interface, OR
2. Upload new files to replace old ones
3. Game automatically rebuilds and redeploys
4. Changes appear within minutes

## Features Available Online
✅ Full 3D strategy gameplay  
✅ All building types and enemy varieties  
✅ Empire management and resource production  
✅ Territory conquest and military training  
✅ Save/load via browser local storage  
✅ Works on desktop and mobile browsers  

## Browser Requirements
- Modern browsers (Chrome, Firefox, Safari, Edge)
- WebGL support (most devices from 2015+)
- JavaScript enabled
- Recommended: Desktop or tablet for best experience

Your Empire Defense game will be fully playable online without any downloads or installations required!