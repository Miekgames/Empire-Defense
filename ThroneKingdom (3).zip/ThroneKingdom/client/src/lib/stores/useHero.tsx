import { create } from "zustand";

export type HeroClass = "knight" | "archer" | "mage";

export interface HeroSkill {
  id: string;
  name: string;
  description: string;
  cost: number;
  unlocked: boolean;
  prereq?: string;
}

export interface Hero {
  class: HeroClass;
  level: number;
  experience: number;
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
  x: number;
  z: number;
  skills: Record<string, HeroSkill>;
  skillPoints: number;
  isAlive: boolean;
}

interface HeroState {
  hero: Hero | null;
  selectedClass: HeroClass | null;
  
  selectHeroClass: (heroClass: HeroClass) => void;
  moveHero: (x: number, z: number) => void;
  takeDamage: (damage: number) => void;
  heal: (amount: number) => void;
  gainExperience: (exp: number) => void;
  unlockSkill: (skillId: string) => void;
  useSkill: (skillId: string) => boolean;
  respawnHero: () => void;
  resetHero: () => void;
}

const heroSkillTrees: Record<HeroClass, Record<string, HeroSkill>> = {
  knight: {
    taunt_aura: {
      id: "taunt_aura",
      name: "Taunt Aura",
      description: "Forces nearby enemies to attack you",
      cost: 1,
      unlocked: false
    },
    shield_wall: {
      id: "shield_wall", 
      name: "Shield Wall",
      description: "Reduces damage taken by 50% for 10 seconds",
      cost: 2,
      unlocked: false,
      prereq: "taunt_aura"
    },
    rally_cry: {
      id: "rally_cry",
      name: "Rally Cry", 
      description: "Boosts all building attack speed by 100%",
      cost: 3,
      unlocked: false,
      prereq: "shield_wall"
    }
  },
  archer: {
    multi_shot: {
      id: "multi_shot",
      name: "Multi Shot",
      description: "Fires 3 arrows at once",
      cost: 1,
      unlocked: false
    },
    explosive_arrow: {
      id: "explosive_arrow",
      name: "Explosive Arrow",
      description: "Arrows explode on impact, dealing area damage",
      cost: 2,
      unlocked: false,
      prereq: "multi_shot"
    },
    arrow_storm: {
      id: "arrow_storm",
      name: "Arrow Storm",
      description: "Rains arrows over a large area for 5 seconds",
      cost: 3,
      unlocked: false,
      prereq: "explosive_arrow"
    }
  },
  mage: {
    fireball: {
      id: "fireball",
      name: "Fireball",
      description: "Launches a fireball that deals splash damage",
      cost: 1,
      unlocked: false
    },
    ice_shard: {
      id: "ice_shard", 
      name: "Ice Shard",
      description: "Slows enemies by 50% for 5 seconds",
      cost: 2,
      unlocked: false,
      prereq: "fireball"
    },
    meteor_shower: {
      id: "meteor_shower",
      name: "Meteor Shower",
      description: "Summons meteors that devastate enemies",
      cost: 3,
      unlocked: false,
      prereq: "ice_shard"
    }
  }
};

const heroBaseStats: Record<HeroClass, {health: number, mana: number}> = {
  knight: { health: 200, mana: 50 },
  archer: { health: 120, mana: 100 },
  mage: { health: 80, mana: 150 }
};

export const useHero = create<HeroState>((set, get) => ({
  hero: null,
  selectedClass: null,

  selectHeroClass: (heroClass) => {
    const baseStats = heroBaseStats[heroClass];
    const skills = { ...heroSkillTrees[heroClass] };
    
    set({
      selectedClass: heroClass,
      hero: {
        class: heroClass,
        level: 1,
        experience: 0,
        health: baseStats.health,
        maxHealth: baseStats.health,
        mana: baseStats.mana,
        maxMana: baseStats.mana,
        x: 0,
        z: 0,
        skills,
        skillPoints: 1,
        isAlive: true
      }
    });
  },

  moveHero: (x, z) => {
    set(state => ({
      hero: state.hero ? { ...state.hero, x, z } : null
    }));
  },

  takeDamage: (damage) => {
    set(state => {
      if (!state.hero) return state;
      const newHealth = Math.max(0, state.hero.health - damage);
      return {
        hero: {
          ...state.hero,
          health: newHealth,
          isAlive: newHealth > 0
        }
      };
    });
  },

  heal: (amount) => {
    set(state => ({
      hero: state.hero ? {
        ...state.hero,
        health: Math.min(state.hero.maxHealth, state.hero.health + amount)
      } : null
    }));
  },

  gainExperience: (exp) => {
    set(state => {
      if (!state.hero) return state;
      const newExp = state.hero.experience + exp;
      const expNeeded = state.hero.level * 100;
      
      if (newExp >= expNeeded) {
        return {
          hero: {
            ...state.hero,
            experience: newExp - expNeeded,
            level: state.hero.level + 1,
            skillPoints: state.hero.skillPoints + 1,
            maxHealth: state.hero.maxHealth + 20,
            health: state.hero.health + 20,
            maxMana: state.hero.maxMana + 10,
            mana: state.hero.mana + 10
          }
        };
      }
      
      return {
        hero: { ...state.hero, experience: newExp }
      };
    });
  },

  unlockSkill: (skillId) => {
    set(state => {
      if (!state.hero || state.hero.skillPoints <= 0) return state;
      
      const skill = state.hero.skills[skillId];
      if (!skill || skill.unlocked) return state;
      
      // Check prerequisites
      if (skill.prereq && !state.hero.skills[skill.prereq]?.unlocked) {
        return state;
      }
      
      return {
        hero: {
          ...state.hero,
          skillPoints: state.hero.skillPoints - skill.cost,
          skills: {
            ...state.hero.skills,
            [skillId]: { ...skill, unlocked: true }
          }
        }
      };
    });
  },

  useSkill: (skillId) => {
    const state = get();
    if (!state.hero || !state.hero.skills[skillId]?.unlocked || !state.hero.isAlive) {
      return false;
    }
    
    const manaCost = 30; // Base mana cost for skills
    if (state.hero.mana < manaCost) return false;
    
    set(state => ({
      hero: state.hero ? {
        ...state.hero,
        mana: Math.max(0, state.hero.mana - manaCost)
      } : null
    }));
    
    return true;
  },

  respawnHero: () => {
    set(state => ({
      hero: state.hero ? {
        ...state.hero,
        health: state.hero.maxHealth,
        mana: state.hero.maxMana,
        x: 0,
        z: 0,
        isAlive: true
      } : null
    }));
  },

  resetHero: () => {
    set({ hero: null, selectedClass: null });
  }
}));