import { create } from "zustand";

export type ResourceType = "food" | "wood" | "stone" | "gold" | "power";
export type TechnologyType = "agriculture" | "construction" | "military" | "research" | "economy";
export type BuildingCategory = "economic" | "military" | "research" | "infrastructure";

export interface Technology {
  id: string;
  name: string;
  type: TechnologyType;
  description: string;
  cost: Record<ResourceType, number>;
  researchTime: number;
  prerequisites: string[];
  bonuses: {
    type: string;
    value: number;
  }[];
  unlocked: boolean;
  researching: boolean;
  timeRemaining: number;
}

export interface CityBuilding {
  id: string;
  type: string;
  name: string;
  category: BuildingCategory;
  level: number;
  maxLevel: number;
  x: number;
  z: number;
  productionRate: Record<ResourceType, number>;
  capacity: Record<ResourceType, number>;
  upgradeTime: number;
  upgradeCost: Record<ResourceType, number>;
  isUpgrading: boolean;
  upgradeTimeRemaining: number;
}

export interface Alliance {
  id: string;
  name: string;
  members: string[];
  power: number;
  description: string;
}

interface EmpireState {
  // Resources
  resources: Record<ResourceType, number>;
  resourceCaps: Record<ResourceType, number>;
  
  // City
  cityBuildings: CityBuilding[];
  population: number;
  maxPopulation: number;
  happiness: number;
  
  // Technology
  technologies: Technology[];
  researchQueue: string[];
  
  // Military
  armyPower: number;
  troops: Record<string, number>;
  
  // Alliance
  currentAlliance: Alliance | null;
  allianceRequests: Alliance[];
  
  // Actions
  addResource: (type: ResourceType, amount: number) => void;
  spendResources: (cost: Record<ResourceType, number>) => boolean;
  canAffordResources: (cost: Record<ResourceType, number>) => boolean;
  
  upgradeBuilding: (buildingId: string) => boolean;
  constructBuilding: (type: string, x: number, z: number) => boolean;
  
  startResearch: (techId: string) => boolean;
  updateResearch: (deltaTime: number) => void;
  
  updateProduction: (deltaTime: number) => void;
  updateUpgrades: (deltaTime: number) => void;
  
  joinAlliance: (allianceId: string) => void;
  leaveAlliance: () => void;
  
  resetEmpire: () => void;
}

const initialTechnologies: Technology[] = [
  {
    id: "basic_farming",
    name: "Basic Farming",
    type: "agriculture",
    description: "Increases food production by 25%",
    cost: { food: 0, wood: 100, stone: 0, gold: 50, power: 0 },
    researchTime: 30,
    prerequisites: [],
    bonuses: [{ type: "food_production", value: 0.25 }],
    unlocked: true,
    researching: false,
    timeRemaining: 0
  },
  {
    id: "stone_masonry",
    name: "Stone Masonry",
    type: "construction",
    description: "Unlocks advanced defensive structures",
    cost: { food: 0, wood: 50, stone: 200, gold: 100, power: 0 },
    researchTime: 45,
    prerequisites: [],
    bonuses: [{ type: "defense_bonus", value: 0.2 }],
    unlocked: true,
    researching: false,
    timeRemaining: 0
  },
  {
    id: "iron_working",
    name: "Iron Working",
    type: "military",
    description: "Unlocks advanced military units",
    cost: { food: 100, wood: 0, stone: 300, gold: 200, power: 0 },
    researchTime: 60,
    prerequisites: ["stone_masonry"],
    bonuses: [{ type: "military_power", value: 0.3 }],
    unlocked: false,
    researching: false,
    timeRemaining: 0
  },
  {
    id: "mathematics",
    name: "Mathematics",
    type: "research",
    description: "Increases research speed by 20%",
    cost: { food: 50, wood: 100, stone: 0, gold: 300, power: 0 },
    researchTime: 40,
    prerequisites: [],
    bonuses: [{ type: "research_speed", value: 0.2 }],
    unlocked: true,
    researching: false,
    timeRemaining: 0
  },
  {
    id: "trade_routes",
    name: "Trade Routes",
    type: "economy",
    description: "Increases gold generation by 35%",
    cost: { food: 200, wood: 150, stone: 0, gold: 100, power: 0 },
    researchTime: 50,
    prerequisites: ["basic_farming"],
    bonuses: [{ type: "gold_production", value: 0.35 }],
    unlocked: false,
    researching: false,
    timeRemaining: 0
  }
];

const initialBuildings: CityBuilding[] = [
  {
    id: "city_hall",
    type: "city_hall",
    name: "City Hall",
    category: "infrastructure",
    level: 1,
    maxLevel: 25,
    x: 0,
    z: 0,
    productionRate: { food: 0, wood: 0, stone: 0, gold: 10, power: 5 },
    capacity: { food: 1000, wood: 1000, stone: 1000, gold: 2000, power: 100 },
    upgradeTime: 60,
    upgradeCost: { food: 100, wood: 200, stone: 150, gold: 300, power: 0 },
    isUpgrading: false,
    upgradeTimeRemaining: 0
  }
];

export const useEmpire = create<EmpireState>((set, get) => ({
  resources: { food: 500, wood: 300, stone: 200, gold: 1000, power: 50 },
  resourceCaps: { food: 1000, wood: 1000, stone: 1000, gold: 2000, power: 100 },
  
  cityBuildings: initialBuildings,
  population: 100,
  maxPopulation: 500,
  happiness: 75,
  
  technologies: initialTechnologies,
  researchQueue: [],
  
  armyPower: 1000,
  troops: { infantry: 10, archers: 5, cavalry: 2 },
  
  currentAlliance: null,
  allianceRequests: [],

  addResource: (type, amount) => {
    set(state => ({
      resources: {
        ...state.resources,
        [type]: Math.min(state.resources[type] + amount, state.resourceCaps[type])
      }
    }));
  },

  spendResources: (cost) => {
    const state = get();
    
    // Check if we can afford it
    for (const [resource, amount] of Object.entries(cost)) {
      if (state.resources[resource as ResourceType] < amount) {
        return false;
      }
    }
    
    // Spend the resources
    set(state => {
      const newResources = { ...state.resources };
      for (const [resource, amount] of Object.entries(cost)) {
        newResources[resource as ResourceType] -= amount;
      }
      return { resources: newResources };
    });
    
    return true;
  },

  canAffordResources: (cost) => {
    const state = get();
    for (const [resource, amount] of Object.entries(cost)) {
      if (state.resources[resource as ResourceType] < amount) {
        return false;
      }
    }
    return true;
  },

  upgradeBuilding: (buildingId) => {
    const state = get();
    const building = state.cityBuildings.find(b => b.id === buildingId);
    
    if (!building || building.isUpgrading || building.level >= building.maxLevel) {
      return false;
    }
    
    if (!state.canAffordResources(building.upgradeCost)) {
      return false;
    }
    
    state.spendResources(building.upgradeCost);
    
    set(state => ({
      cityBuildings: state.cityBuildings.map(b =>
        b.id === buildingId
          ? { ...b, isUpgrading: true, upgradeTimeRemaining: b.upgradeTime }
          : b
      )
    }));
    
    return true;
  },

  constructBuilding: (type, x, z) => {
    // Implementation for new building construction
    return true;
  },

  startResearch: (techId) => {
    const state = get();
    const tech = state.technologies.find(t => t.id === techId);
    
    if (!tech || !tech.unlocked || tech.researching || state.researchQueue.length > 0) {
      return false;
    }
    
    if (!state.canAffordResources(tech.cost)) {
      return false;
    }
    
    state.spendResources(tech.cost);
    
    set(state => ({
      technologies: state.technologies.map(t =>
        t.id === techId
          ? { ...t, researching: true, timeRemaining: t.researchTime }
          : t
      )
    }));
    
    return true;
  },

  updateResearch: (deltaTime) => {
    set(state => ({
      technologies: state.technologies.map(tech => {
        if (!tech.researching) return tech;
        
        const newTimeRemaining = Math.max(0, tech.timeRemaining - deltaTime);
        
        if (newTimeRemaining === 0) {
          // Research completed - unlock prerequisites
          const updatedTechs = state.technologies.map(t => {
            if (tech.prerequisites.includes(t.id)) {
              return { ...t, unlocked: true };
            }
            return t;
          });
          
          return { ...tech, researching: false, timeRemaining: 0 };
        }
        
        return { ...tech, timeRemaining: newTimeRemaining };
      })
    }));
  },

  updateProduction: (deltaTime) => {
    const state = get();
    
    state.cityBuildings.forEach(building => {
      Object.entries(building.productionRate).forEach(([resource, rate]) => {
        if (rate > 0) {
          state.addResource(resource as ResourceType, rate * deltaTime / 60); // per minute
        }
      });
    });
  },

  updateUpgrades: (deltaTime) => {
    set(state => ({
      cityBuildings: state.cityBuildings.map(building => {
        if (!building.isUpgrading) return building;
        
        const newTimeRemaining = Math.max(0, building.upgradeTimeRemaining - deltaTime);
        
        if (newTimeRemaining === 0) {
          return {
            ...building,
            level: building.level + 1,
            isUpgrading: false,
            upgradeTimeRemaining: 0,
            // Increase production and capacity on upgrade
            productionRate: Object.fromEntries(
              Object.entries(building.productionRate).map(([res, rate]) => 
                [res, rate * 1.1]
              )
            ) as Record<ResourceType, number>,
            capacity: Object.fromEntries(
              Object.entries(building.capacity).map(([res, cap]) => 
                [res, cap * 1.2]
              )
            ) as Record<ResourceType, number>
          };
        }
        
        return { ...building, upgradeTimeRemaining: newTimeRemaining };
      })
    }));
  },

  joinAlliance: (allianceId) => {
    // Implementation for joining alliances
  },

  leaveAlliance: () => {
    set({ currentAlliance: null });
  },

  resetEmpire: () => {
    set({
      resources: { food: 500, wood: 300, stone: 200, gold: 1000, power: 50 },
      cityBuildings: initialBuildings,
      technologies: initialTechnologies,
      researchQueue: [],
      currentAlliance: null
    });
  }
}));