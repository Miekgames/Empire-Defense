import { create } from "zustand";

export type HazardType = "bridge" | "rockslide" | "tar_pit" | "spike_trap";

export interface Hazard {
  id: string;
  type: HazardType;
  x: number;
  z: number;
  isActive: boolean;
  isTriggered: boolean;
  damage: number;
  effectRadius: number;
  cooldown: number;
  lastUsed: number;
}

interface HazardState {
  hazards: Hazard[];
  
  placeHazard: (type: HazardType, x: number, z: number) => void;
  triggerHazard: (hazardId: string) => void;
  updateHazards: (deltaTime: number) => void;
  removeHazard: (hazardId: string) => void;
  resetHazards: () => void;
}

const hazardTemplates: Record<HazardType, Omit<Hazard, 'id' | 'x' | 'z' | 'isTriggered' | 'lastUsed'>> = {
  bridge: {
    type: "bridge",
    isActive: true,
    damage: 0,
    effectRadius: 1.5,
    cooldown: 30
  },
  rockslide: {
    type: "rockslide", 
    isActive: true,
    damage: 100,
    effectRadius: 2,
    cooldown: 45
  },
  tar_pit: {
    type: "tar_pit",
    isActive: true,
    damage: 20,
    effectRadius: 1.8,
    cooldown: 15
  },
  spike_trap: {
    type: "spike_trap",
    isActive: true,
    damage: 80,
    effectRadius: 1,
    cooldown: 20
  }
};

export const useHazards = create<HazardState>((set, get) => ({
  hazards: [],

  placeHazard: (type, x, z) => {
    const template = hazardTemplates[type];
    const newHazard: Hazard = {
      ...template,
      id: `${type}-${Date.now()}-${Math.random()}`,
      x,
      z,
      isTriggered: false,
      lastUsed: 0
    };
    
    set(state => ({ 
      hazards: [...state.hazards, newHazard] 
    }));
  },

  triggerHazard: (hazardId) => {
    const currentTime = Date.now();
    
    set(state => ({
      hazards: state.hazards.map(hazard =>
        hazard.id === hazardId && currentTime - hazard.lastUsed > hazard.cooldown * 1000
          ? { ...hazard, isTriggered: true, lastUsed: currentTime }
          : hazard
      )
    }));
  },

  updateHazards: (deltaTime) => {
    set(state => ({
      hazards: state.hazards.map(hazard => ({
        ...hazard,
        isTriggered: false // Reset triggered state each frame
      }))
    }));
  },

  removeHazard: (hazardId) => {
    set(state => ({
      hazards: state.hazards.filter(hazard => hazard.id !== hazardId)
    }));
  },

  resetHazards: () => {
    set({ hazards: [] });
  }
}));