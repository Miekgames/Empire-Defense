import { create } from "zustand";

export type CraftingMaterial = "essence" | "wood" | "stone" | "metal";

export interface CraftingResource {
  type: CraftingMaterial;
  amount: number;
}

export interface TowerMod {
  id: string;
  name: string;
  description: string;
  effect: string;
  materials: CraftingResource[];
  rarity: "common" | "rare" | "epic" | "legendary";
}

export interface CraftedTower {
  buildingId: string;
  mods: TowerMod[];
}

interface CraftingState {
  materials: Record<CraftingMaterial, number>;
  availableMods: TowerMod[];
  craftedTowers: CraftedTower[];
  
  addMaterial: (type: CraftingMaterial, amount: number) => void;
  spendMaterials: (cost: CraftingResource[]) => boolean;
  craftMod: (modId: string) => TowerMod | null;
  applyModToTower: (buildingId: string, mod: TowerMod) => void;
  removeMod: (buildingId: string, modIndex: number) => void;
  resetCrafting: () => void;
}

const availableTowerMods: TowerMod[] = [
  {
    id: "explosive_shots",
    name: "Explosive Shots",
    description: "Shots explode on impact for area damage",
    effect: "splash_damage",
    materials: [
      { type: "essence", amount: 5 },
      { type: "metal", amount: 3 }
    ],
    rarity: "common"
  },
  {
    id: "poison_cloud",
    name: "Poison Cloud",
    description: "Enemies take damage over time",
    effect: "poison_dot",
    materials: [
      { type: "essence", amount: 8 },
      { type: "wood", amount: 5 }
    ],
    rarity: "rare"
  },
  {
    id: "range_extension",
    name: "Range Extension",
    description: "Increases tower range by 50%",
    effect: "increased_range",
    materials: [
      { type: "stone", amount: 4 },
      { type: "metal", amount: 2 }
    ],
    rarity: "common"
  },
  {
    id: "rapid_fire",
    name: "Rapid Fire",
    description: "Doubles attack speed",
    effect: "attack_speed",
    materials: [
      { type: "essence", amount: 10 },
      { type: "metal", amount: 6 }
    ],
    rarity: "rare"
  },
  {
    id: "frost_enchant",
    name: "Frost Enchantment",
    description: "Slows enemies by 40%",
    effect: "slow_effect",
    materials: [
      { type: "essence", amount: 12 },
      { type: "stone", amount: 8 }
    ],
    rarity: "epic"
  },
  {
    id: "chain_lightning",
    name: "Chain Lightning",
    description: "Attacks jump between nearby enemies",
    effect: "chain_attack",
    materials: [
      { type: "essence", amount: 20 },
      { type: "metal", amount: 10 },
      { type: "stone", amount: 5 }
    ],
    rarity: "legendary"
  }
];

export const useCrafting = create<CraftingState>((set, get) => ({
  materials: {
    essence: 0,
    wood: 0,
    stone: 0,
    metal: 0
  },
  availableMods: availableTowerMods,
  craftedTowers: [],

  addMaterial: (type, amount) => {
    set(state => ({
      materials: {
        ...state.materials,
        [type]: state.materials[type] + amount
      }
    }));
  },

  spendMaterials: (cost) => {
    const state = get();
    
    // Check if we have enough materials
    for (const resource of cost) {
      if (state.materials[resource.type] < resource.amount) {
        return false;
      }
    }
    
    // Spend the materials
    set(state => {
      const newMaterials = { ...state.materials };
      for (const resource of cost) {
        newMaterials[resource.type] -= resource.amount;
      }
      return { materials: newMaterials };
    });
    
    return true;
  },

  craftMod: (modId) => {
    const state = get();
    const mod = state.availableMods.find(m => m.id === modId);
    
    if (!mod || !state.spendMaterials(mod.materials)) {
      return null;
    }
    
    return { ...mod };
  },

  applyModToTower: (buildingId, mod) => {
    set(state => {
      const existingTower = state.craftedTowers.find(t => t.buildingId === buildingId);
      
      if (existingTower) {
        // Max 2 mods per tower
        if (existingTower.mods.length >= 2) {
          return state;
        }
        
        return {
          craftedTowers: state.craftedTowers.map(t =>
            t.buildingId === buildingId
              ? { ...t, mods: [...t.mods, mod] }
              : t
          )
        };
      } else {
        return {
          craftedTowers: [...state.craftedTowers, {
            buildingId,
            mods: [mod]
          }]
        };
      }
    });
  },

  removeMod: (buildingId, modIndex) => {
    set(state => ({
      craftedTowers: state.craftedTowers.map(t =>
        t.buildingId === buildingId
          ? { ...t, mods: t.mods.filter((_, i) => i !== modIndex) }
          : t
      ).filter(t => t.mods.length > 0)
    }));
  },

  resetCrafting: () => {
    set({
      materials: { essence: 0, wood: 0, stone: 0, metal: 0 },
      craftedTowers: []
    });
  }
}));