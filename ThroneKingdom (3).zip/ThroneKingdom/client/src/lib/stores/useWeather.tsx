import { create } from "zustand";

export type WeatherType = "clear" | "winter" | "storm" | "flood";

export interface WeatherEffect {
  type: WeatherType;
  name: string;
  description: string;
  duration: number;
  effects: {
    towerSpeedMultiplier?: number;
    enemySpeedMultiplier?: number;
    goldMultiplier?: number;
    damageMultiplier?: number;
    pathBlocked?: boolean;
  };
}

interface WeatherState {
  currentWeather: WeatherType;
  timeRemaining: number;
  isActive: boolean;
  
  setWeather: (weather: WeatherType) => void;
  updateWeather: (deltaTime: number) => void;
  clearWeather: () => void;
  randomWeatherEvent: () => void;
}

const weatherEffects: Record<WeatherType, WeatherEffect> = {
  clear: {
    type: "clear",
    name: "Clear Skies",
    description: "Perfect weather for defending",
    duration: 0,
    effects: {}
  },
  winter: {
    type: "winter",
    name: "Winter Freeze",
    description: "Towers fire slower, but enemies move slower too",
    duration: 30,
    effects: {
      towerSpeedMultiplier: 0.7,
      enemySpeedMultiplier: 0.8
    }
  },
  storm: {
    type: "storm",
    name: "Lightning Storm",
    description: "Lightning towers deal extra damage",
    duration: 20,
    effects: {
      damageMultiplier: 1.5
    }
  },
  flood: {
    type: "flood",
    name: "Spring Flood",
    description: "Enemy paths may be altered",
    duration: 25,
    effects: {
      enemySpeedMultiplier: 0.6,
      pathBlocked: true
    }
  }
};

export const useWeather = create<WeatherState>((set, get) => ({
  currentWeather: "clear",
  timeRemaining: 0,
  isActive: false,

  setWeather: (weather) => {
    const effect = weatherEffects[weather];
    set({
      currentWeather: weather,
      timeRemaining: effect.duration,
      isActive: weather !== "clear"
    });
  },

  updateWeather: (deltaTime) => {
    const state = get();
    if (!state.isActive) return;

    const newTime = Math.max(0, state.timeRemaining - deltaTime);
    
    if (newTime <= 0) {
      set({
        currentWeather: "clear",
        timeRemaining: 0,
        isActive: false
      });
    } else {
      set({ timeRemaining: newTime });
    }
  },

  clearWeather: () => {
    set({
      currentWeather: "clear",
      timeRemaining: 0,
      isActive: false
    });
  },

  randomWeatherEvent: () => {
    const weatherTypes: WeatherType[] = ["winter", "storm", "flood"];
    const randomWeather = weatherTypes[Math.floor(Math.random() * weatherTypes.length)];
    get().setWeather(randomWeather);
  }
}));

export { weatherEffects };