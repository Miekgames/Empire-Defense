import { findPath } from "./pathfinding";
import { useBuildings } from "./stores/useBuildings";
import { useEnemies } from "./stores/useEnemies";
import { useResources } from "./stores/useResources";

interface GameLogicProps {
  phase: string;
  currentWave: number;
  buildings: any[];
  enemies: any[];
  updateEnemies: (deltaTime: number) => void;
  startWave: () => void;
  endWave: (success: boolean) => void;
  addGold: (amount: number) => void;
  playHit: () => void;
  playSuccess: () => void;
}

let waveStartTime = 0;
let nextEnemySpawn = 0;
let enemiesSpawned = 0;
let lastGoldGeneration = 0;

export function updateGameLogic(deltaTime: number, props: GameLogicProps) {
  const { 
    phase, 
    currentWave, 
    buildings, 
    enemies, 
    updateEnemies,
    endWave,
    addGold,
    playHit,
    playSuccess
  } = props;

  const currentTime = Date.now();

  // Generate gold from houses
  if (currentTime - lastGoldGeneration > 2000) { // Every 2 seconds
    const houses = buildings.filter(b => b.type === 'house' && b.health > 0);
    const goldGenerated = houses.length * 5;
    if (goldGenerated > 0) {
      addGold(goldGenerated);
    }
    lastGoldGeneration = currentTime;
  }

  if (phase === 'wave') {
    // Initialize wave
    if (waveStartTime === 0) {
      waveStartTime = currentTime;
      nextEnemySpawn = currentTime;
      enemiesSpawned = 0;
    }

    // Spawn enemies
    const enemiesToSpawn = Math.min(currentWave * 3, 20);
    const spawnInterval = Math.max(1000 - currentWave * 50, 300);
    
    if (currentTime >= nextEnemySpawn && enemiesSpawned < enemiesToSpawn) {
      spawnEnemy(currentWave);
      enemiesSpawned++;
      nextEnemySpawn = currentTime + spawnInterval;
    }

    // Update enemies
    updateEnemies(deltaTime);

    // Handle combat
    handleCombat(buildings, enemies, playHit);

    // Clean up dead enemies first
    cleanupDeadEntities(enemies, buildings);

    // Check win/lose conditions
    const throne = buildings.find(b => b.type === 'throne');
    if (!throne || throne.health <= 0) {
      // Clear all enemies when game over
      useEnemies.getState().clearEnemies();
      endWave(false); // Game over
      resetWaveState();
      return;
    }

    // Check if wave is complete - get fresh enemy count
    const currentEnemies = useEnemies.getState().enemies;
    if (enemiesSpawned >= enemiesToSpawn && currentEnemies.length === 0) {
      playSuccess();
      addGold(currentWave * 25); // Bonus gold
      endWave(true);
      resetWaveState();
    }
  } else {
    // Clear enemies when not in wave phase and reset wave state
    if (phase === 'building' || phase === 'gameOver' || phase === 'victory') {
      useEnemies.getState().clearEnemies();
    }
    resetWaveState();
  }
}

function spawnEnemy(wave: number) {
  const { spawnEnemy } = useEnemies.getState();
  
  // Create enemy pool based on wave number - more variety as waves progress
  const enemyPool = ['peasant'];
  
  if (wave >= 2) enemyPool.push('archer');
  if (wave >= 3) enemyPool.push('swordsman');
  if (wave >= 4) enemyPool.push('spearman');
  if (wave >= 5) enemyPool.push('racer');
  if (wave >= 6) enemyPool.push('exploder');
  if (wave >= 7) enemyPool.push('ogre');
  
  // Higher waves increase chance of stronger enemies
  let enemyType: any;
  if (wave <= 3) {
    enemyType = enemyPool[Math.floor(Math.random() * Math.min(2, enemyPool.length))];
  } else if (wave <= 6) {
    enemyType = enemyPool[Math.floor(Math.random() * Math.min(4, enemyPool.length))];
  } else {
    enemyType = enemyPool[Math.floor(Math.random() * enemyPool.length)];
  }
  
  // Random spawn position at edge
  const angle = Math.random() * Math.PI * 2;
  const distance = 9;
  const x = Math.cos(angle) * distance;
  const z = Math.sin(angle) * distance;
  
  spawnEnemy(enemyType, x, z);
}

function handleCombat(buildings: any[], enemies: any[], playHit: () => void) {
  const { damageEnemy, removeEnemy } = useEnemies.getState();
  const { damageBuilding } = useBuildings.getState();
  const { loseLives } = useResources.getState();
  
  const currentTime = Date.now();

  // Tower attacks
  buildings.forEach(building => {
    if (building.type === 'tower' && building.health > 0) {
      if (currentTime - building.lastAttack > 1000) { // Attack every second
        const nearbyEnemies = enemies.filter(enemy => {
          const distance = Math.sqrt(
            Math.pow(enemy.x - building.x, 2) + Math.pow(enemy.z - building.z, 2)
          );
          return distance <= 3; // Tower range
        });

        if (nearbyEnemies.length > 0) {
          const target = nearbyEnemies[0];
          damageEnemy(target.id, 25);
          playHit();
          building.lastAttack = currentTime;
        }
      }
    }
  });

  // Enemy attacks
  enemies.forEach(enemy => {
    const nearbyBuildings = buildings.filter(building => {
      const distance = Math.sqrt(
        Math.pow(enemy.x - building.x, 2) + Math.pow(enemy.z - building.z, 2)
      );
      return distance <= 0.8 && building.health > 0;
    });

    if (nearbyBuildings.length > 0 && currentTime - enemy.lastDamageTime > 1500) {
      const target = nearbyBuildings[0];
      damageBuilding(target.id, enemy.damage);
      enemy.lastDamageTime = currentTime;
    }
  });

  // Handle enemy deaths and explosions
  enemies.forEach(enemy => {
    if (enemy.health <= 0) {
      // Handle exploder death explosion
      if (enemy.behavior === 'exploder') {
        handleExplosion(enemy.x, enemy.z, buildings, enemies);
      }
      
      useResources.getState().addGold(enemy.gold);
      removeEnemy(enemy.id);
    }
  });

  // Check if enemies reached the end (throne position)
  enemies.forEach(enemy => {
    const distanceToThrone = Math.sqrt(enemy.x * enemy.x + enemy.z * enemy.z);
    if (distanceToThrone < 0.5) {
      // Exploders explode when reaching throne
      if (enemy.behavior === 'exploder') {
        handleExplosion(enemy.x, enemy.z, buildings, enemies);
      }
      
      // Racers do more damage to throne
      const damageAmount = enemy.behavior === 'rusher' ? 2 : 1;
      loseLives(damageAmount);
      removeEnemy(enemy.id);
    }
  });
}

function cleanupDeadEntities(enemies: any[], buildings: any[]) {
  const { removeEnemy } = useEnemies.getState();
  const { removeBuilding } = useBuildings.getState();

  // Remove dead enemies
  enemies.forEach(enemy => {
    if (enemy.health <= 0) {
      removeEnemy(enemy.id);
    }
  });

  // Remove dead buildings (except throne)
  buildings.forEach(building => {
    if (building.health <= 0 && building.type !== 'throne') {
      removeBuilding(building.id);
    }
  });
}

function handleExplosion(x: number, z: number, buildings: any[], enemies: any[]) {
  const { damageBuilding } = useBuildings.getState();
  const { damageEnemy } = useEnemies.getState();
  const explosionRadius = 2;
  const explosionDamage = 80;

  // Damage nearby buildings
  buildings.forEach(building => {
    const distance = Math.sqrt(
      Math.pow(building.x - x, 2) + Math.pow(building.z - z, 2)
    );
    if (distance <= explosionRadius) {
      damageBuilding(building.id, explosionDamage);
    }
  });

  // Damage nearby enemies (chain explosions)
  enemies.forEach(enemy => {
    if (enemy.behavior !== 'exploder') return; // Only chain with other exploders
    
    const distance = Math.sqrt(
      Math.pow(enemy.x - x, 2) + Math.pow(enemy.z - z, 2)
    );
    if (distance <= explosionRadius && distance > 0.1) {
      damageEnemy(enemy.id, explosionDamage);
    }
  });
}

function resetWaveState() {
  waveStartTime = 0;
  nextEnemySpawn = 0;
  enemiesSpawned = 0;
}
