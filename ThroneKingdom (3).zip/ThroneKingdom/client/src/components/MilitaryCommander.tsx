import { useState } from "react";
import { useEmpire } from "../lib/stores/useEmpire";
import { useResources } from "../lib/stores/useResources";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  Sword, 
  Shield, 
  Users, 
  Clock, 
  Target,
  Crown,
  Zap,
  ArrowUp,
  Play,
  Pause
} from "lucide-react";

interface TroopType {
  id: string;
  name: string;
  description: string;
  cost: { food: number; gold: number; };
  trainingTime: number;
  power: number;
  category: "infantry" | "ranged" | "cavalry" | "siege";
  unlocked: boolean;
}

interface TrainingQueue {
  id: string;
  troopType: string;
  quantity: number;
  timeRemaining: number;
  totalTime: number;
}

const troopTypes: TroopType[] = [
  {
    id: "militia",
    name: "Militia",
    description: "Basic infantry units with moderate combat ability",
    cost: { food: 100, gold: 50 },
    trainingTime: 30,
    power: 50,
    category: "infantry",
    unlocked: true
  },
  {
    id: "spearmen",
    name: "Spearmen",
    description: "Anti-cavalry specialists with strong defensive capabilities",
    cost: { food: 150, gold: 75 },
    trainingTime: 45,
    power: 75,
    category: "infantry",
    unlocked: true
  },
  {
    id: "archers",
    name: "Archers",
    description: "Ranged units effective against infantry",
    cost: { food: 120, gold: 80 },
    trainingTime: 40,
    power: 60,
    category: "ranged",
    unlocked: true
  },
  {
    id: "crossbowmen",
    name: "Crossbowmen",
    description: "Heavy ranged units with armor piercing",
    cost: { food: 200, gold: 150 },
    trainingTime: 60,
    power: 90,
    category: "ranged",
    unlocked: false
  },
  {
    id: "knights",
    name: "Knights",
    description: "Elite heavy cavalry with devastating charges",
    cost: { food: 300, gold: 250 },
    trainingTime: 90,
    power: 150,
    category: "cavalry",
    unlocked: false
  },
  {
    id: "catapults",
    name: "Catapults",
    description: "Siege engines for breaking enemy fortifications",
    cost: { food: 500, gold: 400 },
    trainingTime: 120,
    power: 200,
    category: "siege",
    unlocked: false
  }
];

const categoryIcons = {
  infantry: Shield,
  ranged: Target,
  cavalry: Crown,
  siege: Sword
};

export default function MilitaryCommander() {
  const [selectedTroop, setSelectedTroop] = useState<TroopType | null>(null);
  const [trainingQuantity, setTrainingQuantity] = useState(1);
  const [trainingQueue, setTrainingQueue] = useState<TrainingQueue[]>([]);
  const [showCommander, setShowCommander] = useState(false);
  
  const { troops, armyPower, canAffordResources, spendResources } = useEmpire();
  const { gold } = useResources();

  const getTotalTroopCount = () => {
    return Object.values(troops).reduce((sum, count) => sum + count, 0);
  };

  const handleTrainTroops = (troopType: TroopType, quantity: number) => {
    const totalCost = {
      food: troopType.cost.food * quantity,
      gold: troopType.cost.gold * quantity,
      wood: 0,
      stone: 0,
      power: 0
    };

    if (!canAffordResources(totalCost)) return;

    spendResources(totalCost);

    const newTraining: TrainingQueue = {
      id: `${troopType.id}-${Date.now()}`,
      troopType: troopType.id,
      quantity,
      timeRemaining: troopType.trainingTime * quantity,
      totalTime: troopType.trainingTime * quantity
    };

    setTrainingQueue(prev => [...prev, newTraining]);
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) return `${hours}h ${minutes}m`;
    if (minutes > 0) return `${minutes}m ${secs}s`;
    return `${secs}s`;
  };

  if (!showCommander) {
    return (
      <Button
        onClick={() => setShowCommander(true)}
        variant="outline"
        size="sm"
        className="fixed bottom-4 left-4 bg-black/80 text-white border-red-500 hover:bg-red-500/20"
      >
        <Sword className="w-4 h-4 mr-2" />
        Military
      </Button>
    );
  }

  return (
    <div className="fixed left-4 top-1/2 transform -translate-y-1/2 w-80 max-h-[80vh] overflow-y-auto pointer-events-auto">
      <Card className="bg-black/90 text-white border-red-500">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sword className="w-6 h-6 text-red-500" />
              <CardTitle className="text-lg">Military Commander</CardTitle>
            </div>
            <Button
              onClick={() => setShowCommander(false)}
              variant="ghost"
              size="sm"
            >
              ×
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-4 space-y-4">
          {/* Army Overview */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-red-400">Army Status</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-gray-800 p-2 rounded">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-red-500" />
                  <span className="text-xs text-gray-400">Power</span>
                </div>
                <div className="text-lg font-bold">{armyPower.toLocaleString()}</div>
              </div>
              <div className="bg-gray-800 p-2 rounded">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-500" />
                  <span className="text-xs text-gray-400">Troops</span>
                </div>
                <div className="text-lg font-bold">{getTotalTroopCount()}</div>
              </div>
            </div>
          </div>

          {/* Current Forces */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-red-400">Current Forces</h3>
            <div className="space-y-1">
              {Object.entries(troops).map(([type, count]) => {
                const troopType = troopTypes.find(t => t.id === type);
                if (!troopType || count === 0) return null;
                
                const IconComponent = categoryIcons[troopType.category];
                
                return (
                  <div key={type} className="flex items-center justify-between bg-gray-800 p-2 rounded">
                    <div className="flex items-center gap-2">
                      <IconComponent className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">{troopType.name}</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {count}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Training Queue */}
          {trainingQueue.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-red-400">Training Queue</h3>
              <div className="space-y-2">
                {trainingQueue.map((training) => {
                  const troopType = troopTypes.find(t => t.id === training.troopType);
                  if (!troopType) return null;
                  
                  const progress = ((training.totalTime - training.timeRemaining) / training.totalTime) * 100;
                  
                  return (
                    <div key={training.id} className="bg-gray-800 p-2 rounded">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm">{troopType.name} x{training.quantity}</span>
                        <Badge variant="secondary" className="text-xs">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatTime(training.timeRemaining)}
                        </Badge>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Troop Training */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-red-400">Train Troops</h3>
            <div className="grid grid-cols-2 gap-2">
              {troopTypes.filter(t => t.unlocked).map((troopType) => {
                const IconComponent = categoryIcons[troopType.category];
                const canAfford = canAffordResources({
                  food: troopType.cost.food * trainingQuantity,
                  gold: troopType.cost.gold * trainingQuantity,
                  wood: 0,
                  stone: 0,
                  power: 0
                });
                
                return (
                  <Button
                    key={troopType.id}
                    onClick={() => setSelectedTroop(troopType)}
                    variant={selectedTroop?.id === troopType.id ? "default" : "outline"}
                    className="flex flex-col items-center p-3 h-auto text-xs"
                    disabled={!canAfford}
                  >
                    <IconComponent className="w-4 h-4 mb-1" />
                    <span>{troopType.name}</span>
                    <div className="text-xs text-gray-400">
                      {troopType.cost.food}F {troopType.cost.gold}G
                    </div>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Selected Troop Details */}
          {selectedTroop && (
            <div className="space-y-3 bg-gray-800 p-3 rounded">
              <div className="flex items-center gap-2">
                <span className="font-medium">{selectedTroop.name}</span>
                <Badge variant="outline" className="text-xs">
                  {selectedTroop.power} Power
                </Badge>
              </div>
              
              <p className="text-xs text-gray-400">{selectedTroop.description}</p>
              
              <div className="flex items-center gap-2">
                <Button
                  onClick={() => setTrainingQuantity(Math.max(1, trainingQuantity - 1))}
                  variant="outline"
                  size="sm"
                >
                  -
                </Button>
                <span className="mx-2 font-mono">{trainingQuantity}</span>
                <Button
                  onClick={() => setTrainingQuantity(trainingQuantity + 1)}
                  variant="outline"
                  size="sm"
                >
                  +
                </Button>
              </div>
              
              <div className="text-xs text-gray-400">
                Total Cost: {selectedTroop.cost.food * trainingQuantity} Food, {selectedTroop.cost.gold * trainingQuantity} Gold
              </div>
              <div className="text-xs text-gray-400">
                Training Time: {formatTime(selectedTroop.trainingTime * trainingQuantity)}
              </div>
              
              <Button
                onClick={() => handleTrainTroops(selectedTroop, trainingQuantity)}
                disabled={!canAffordResources({
                  food: selectedTroop.cost.food * trainingQuantity,
                  gold: selectedTroop.cost.gold * trainingQuantity,
                  wood: 0,
                  stone: 0,
                  power: 0
                })}
                className="w-full"
              >
                <Play className="w-4 h-4 mr-2" />
                Train {trainingQuantity} {selectedTroop.name}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}