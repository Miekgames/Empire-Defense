import { useRef, useState } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useBuildings } from "../lib/stores/useBuildings";
import { useGameState } from "../lib/stores/useGameState";
import * as THREE from "three";

const GRID_SIZE = 10;
const CELL_SIZE = 1;

export default function GridOverlay() {
  const { camera, raycaster, pointer } = useThree();
  const { phase } = useGameState();
  const { selectedBuildingType, placeBuilding, isValidPlacement } = useBuildings();
  const [hoveredCell, setHoveredCell] = useState<{ x: number, z: number } | null>(null);
  const planeRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (!planeRef.current || phase !== 'building' || !selectedBuildingType) return;

    // Update raycaster
    raycaster.setFromCamera(pointer, camera);
    const intersects = raycaster.intersectObject(planeRef.current);

    if (intersects.length > 0) {
      const point = intersects[0].point;
      const gridX = Math.floor(point.x + GRID_SIZE / 2);
      const gridZ = Math.floor(point.z + GRID_SIZE / 2);
      
      if (gridX >= 0 && gridX < GRID_SIZE && gridZ >= 0 && gridZ < GRID_SIZE) {
        setHoveredCell({ x: gridX - GRID_SIZE / 2 + 0.5, z: gridZ - GRID_SIZE / 2 + 0.5 });
      } else {
        setHoveredCell(null);
      }
    } else {
      setHoveredCell(null);
    }
  });

  const handleClick = () => {
    if (hoveredCell && selectedBuildingType && phase === 'building') {
      if (isValidPlacement(hoveredCell.x, hoveredCell.z, selectedBuildingType)) {
        placeBuilding(hoveredCell.x, hoveredCell.z, selectedBuildingType);
      }
    }
  };

  if (phase !== 'building' || !selectedBuildingType) return null;

  return (
    <>
      {/* Invisible plane for raycasting */}
      <mesh 
        ref={planeRef}
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0.01, 0]}
        onClick={handleClick}
      >
        <planeGeometry args={[20, 20]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {/* Simplified grid - only show during building phase */}
      <lineSegments>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={((GRID_SIZE + 1) * 2) * 2}
            array={(() => {
              const positions = [];
              // Vertical lines
              for (let i = 0; i <= GRID_SIZE; i++) {
                positions.push(
                  -GRID_SIZE / 2 + i * CELL_SIZE, 0.02, -GRID_SIZE / 2,
                  -GRID_SIZE / 2 + i * CELL_SIZE, 0.02, GRID_SIZE / 2
                );
              }
              // Horizontal lines
              for (let i = 0; i <= GRID_SIZE; i++) {
                positions.push(
                  -GRID_SIZE / 2, 0.02, -GRID_SIZE / 2 + i * CELL_SIZE,
                  GRID_SIZE / 2, 0.02, -GRID_SIZE / 2 + i * CELL_SIZE
                );
              }
              return new Float32Array(positions);
            })()}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#ffffff" opacity={0.3} transparent />
      </lineSegments>

      {/* Hover preview */}
      {hoveredCell && (
        <mesh position={[hoveredCell.x, 0.5, hoveredCell.z]}>
          <boxGeometry args={[0.8, 1, 0.8]} />
          <meshBasicMaterial 
            color={isValidPlacement(hoveredCell.x, hoveredCell.z, selectedBuildingType) ? 'green' : 'red'}
            transparent 
            opacity={0.5} 
          />
        </mesh>
      )}
    </>
  );
}
