import { useGameState } from "../lib/stores/useGameState";
import { useBuildings } from "../lib/stores/useBuildings";
import { useResources } from "../lib/stores/useResources";
import { useAudio } from "../lib/stores/useAudio";
import { useEnemies } from "../lib/stores/useEnemies";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Crown, Coins, Volume2, VolumeX, Shield, Home, Zap, Wrench, Store, Building, Telescope, Wheat, TreePine, Mountain, Gem, Factory, Sword } from "lucide-react";

export default function GameUI() {
  const { phase, currentWave, waveProgress, startWave, resetGame } = useGameState();
  const { selectedBuildingType, setSelectedBuildingType, canAffordBuilding, resetBuildings } = useBuildings();
  const { gold, lives, resetResources } = useResources();
  const { isMuted, toggleMute } = useAudio();
  const { clearEnemies } = useEnemies();

  const buildingTypes = [
    // Defense Buildings
    { type: 'tower', name: 'Tower', cost: 50, icon: Sword, description: 'Attacks enemies', category: 'Defense' },
    { type: 'wall', name: 'Wall', cost: 25, icon: Shield, description: 'Blocks enemies', category: 'Defense' },
    { type: 'watchtower', name: 'Watchtower', cost: 80, icon: Telescope, description: 'Long range attacks', category: 'Defense' },

    // Economic Buildings
    { type: 'house', name: 'House', cost: 75, icon: Home, description: 'Generates gold', category: 'Economic' },
    { type: 'market', name: 'Market', cost: 90, icon: Store, description: 'Trading hub', category: 'Economic' },

    // Resource Buildings
    { type: 'farm', name: 'Farm', cost: 60, icon: Wheat, description: 'Produces food', category: 'Resource' },
    { type: 'lumbermill', name: 'Lumbermill', cost: 70, icon: TreePine, description: 'Produces wood', category: 'Resource' },
    { type: 'quarry', name: 'Quarry', cost: 80, icon: Mountain, description: 'Produces stone', category: 'Resource' },
    { type: 'goldmine', name: 'Gold Mine', cost: 100, icon: Gem, description: 'Produces gold', category: 'Resource' },
    { type: 'powerplant', name: 'Power Plant', cost: 150, icon: Factory, description: 'Produces power', category: 'Resource' },

    // Special Buildings
    { type: 'barracks', name: 'Barracks', cost: 100, icon: Zap, description: 'Spawns defenders', category: 'Special' },
    { type: 'forge', name: 'Forge', cost: 120, icon: Wrench, description: 'Crafts upgrades', category: 'Special' },
    { type: 'temple', name: 'Temple', cost: 150, icon: Building, description: 'Provides buffs', category: 'Special' }
  ];

  const handleResetGame = () => {
    // Clear all game state
    clearEnemies();
    resetBuildings();
    resetResources();
    resetGame();
  };

  return (
    <div className="absolute inset-0 pointer-events-none">
      

      {/* Game Over Reset Button */}
      {phase === 'gameOver' && (
        <div className="absolute top-4 right-4 pointer-events-auto">
          <Button
            onClick={handleResetGame}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            Restart
          </Button>
        </div>
      )}

      {/* Wave Information */}
      {phase === 'building' && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 pointer-events-auto">
          <Card className="bg-black/80 text-white border-blue-500">
            <CardContent className="p-3 text-center">
              <div className="text-lg font-bold">Prepare for Wave {currentWave}</div>
              <Button
                onClick={startWave}
                className="mt-2 bg-blue-600 hover:bg-blue-700 text-white"
              >
                Start Wave
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {phase === 'wave' && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 pointer-events-auto">
          <Card className="bg-black/80 text-white border-red-500">
            <CardContent className="p-3 text-center">
              <div className="text-lg font-bold">Wave {currentWave}</div>
              <div className="w-32 h-2 bg-gray-700 rounded-full mt-2">
                <div 
                  className="h-full bg-red-500 rounded-full transition-all duration-200"
                  style={{ width: `${waveProgress * 100}%` }}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Building Selection Panel */}
      {phase === 'building' && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 pointer-events-auto">
          <Card className="bg-black/90 text-white border-yellow-500">
            <CardContent className="p-4">
              <div className="text-center mb-3 text-lg font-bold">Build Structures</div>

              {/* Resource Buildings Section */}
              <div className="mb-4">
                <div className="text-sm font-semibold text-green-400 mb-2">Resource Production</div>
                <div className="grid grid-cols-5 gap-2">
                  {buildingTypes.filter(b => b.category === 'Resource').map((building) => {
                    const IconComponent = building.icon;
                    const canAfford = canAffordBuilding(building.type as any);

                    return (
                      <Button
                        key={building.type}
                        onClick={() => setSelectedBuildingType(building.type as any)}
                        className={`h-12 p-2 flex flex-col items-center justify-center text-xs ${
                          selectedBuildingType === building.type 
                            ? 'bg-green-600 hover:bg-green-700' 
                            : canAfford 
                              ? 'bg-gray-700 hover:bg-gray-600' 
                              : 'bg-gray-800 cursor-not-allowed opacity-50'
                        }`}
                        disabled={!canAfford}
                        title={`${building.name} - ${building.description} (${building.cost} gold)`}
                      >
                        <IconComponent className="w-4 h-4 mb-1" />
                        <span className="text-xs">{building.cost}g</span>
                      </Button>
                    );
                  })}
                </div>
              </div>

              {/* Defense & Other Buildings */}
              <div className="grid grid-cols-4 gap-2">
                {buildingTypes.filter(b => b.category !== 'Resource').map((building) => {
                  const Icon = building.icon;
                  const canAfford = canAffordBuilding(building.type as any);
                  const isSelected = selectedBuildingType === building.type;

                  return (
                    <Button
                      key={building.type}
                      onClick={() => setSelectedBuildingType(building.type as any)}
                      variant={isSelected ? "default" : "outline"}
                      className={`flex flex-col items-center p-3 h-auto ${
                        canAfford 
                          ? isSelected 
                            ? "bg-yellow-600 hover:bg-yellow-700 text-black border-yellow-500" 
                            : "bg-black/50 text-white border-yellow-500 hover:bg-yellow-500/20"
                          : "bg-gray-800 text-gray-500 border-gray-600 cursor-not-allowed"
                      }`}
                      disabled={!canAfford}
                    >
                      <Icon className="w-6 h-6 mb-1" />
                      <span className="text-sm font-semibold">{building.name}</span>
                      <div className="flex items-center gap-1 text-xs">
                        <Coins className="w-3 h-3" />
                        <span>{building.cost}</span>
                      </div>
                      <span className="text-xs opacity-75 text-center">{building.description}</span>
                    </Button>
                  );
                })}
              </div>
              {selectedBuildingType && (
                <div className="mt-3 text-center text-sm text-yellow-400">
                  Click on the grid to place {buildingTypes.find(b => b.type === selectedBuildingType)?.name}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Game Over Screen */}
      {phase === 'gameOver' && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center pointer-events-auto">
          <Card className="bg-black/90 text-white border-red-500 max-w-md w-full mx-4">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-red-500 mb-4">Game Over</div>
              <div className="text-lg mb-2">Your kingdom has fallen!</div>
              <div className="text-sm text-gray-400 mb-6">
                You survived {currentWave - 1} waves
              </div>
              <Button
                onClick={handleResetGame}
                className="bg-red-600 hover:bg-red-700 text-white w-full"
              >
                Build a New Kingdom
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Victory Screen */}
      {phase === 'victory' && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center pointer-events-auto">
          <Card className="bg-black/90 text-white border-yellow-500 max-w-md w-full mx-4">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-yellow-500 mb-4">Victory!</div>
              <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <div className="text-lg mb-2">Your kingdom stands strong!</div>
              <div className="text-sm text-gray-400 mb-6">
                You defended against all {currentWave} waves
              </div>
              <Button
                onClick={handleResetGame}
                className="bg-yellow-600 hover:bg-yellow-700 text-black w-full"
              >
                Build Another Kingdom
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Audio Control */}
      <div className="absolute bottom-4 right-4 pointer-events-auto">
        <Button
          onClick={toggleMute}
          variant="outline"
          size="icon"
          className="bg-black/80 text-white border-yellow-500 hover:bg-yellow-500/20"
          title={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </Button>
      </div>
    </div>
  );
}