import { useState } from "react";
import { useGameState, MapInfo } from "../lib/stores/useGameState";
import { useEmpire } from "../lib/stores/useEmpire";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  Map, 
  Sword, 
  Crown, 
  Users, 
  Zap, 
  Flag,
  Target,
  Globe,
  Trophy,
  Lock,
  CheckCircle
} from "lucide-react";

interface Territory {
  id: string;
  name: string;
  x: number;
  y: number;
  controlled: boolean;
  contested: boolean;
  resources: string[];
  difficulty: "easy" | "medium" | "hard" | "expert";
  mapId: string;
  enemyPower: number;
  rewards: {
    gold: number;
    resources: Record<string, number>;
    territory: boolean;
  };
}

const territories: Territory[] = [
  {
    id: "green_valley",
    name: "Green Valley",
    x: 25,
    y: 40,
    controlled: true,
    contested: false,
    resources: ["food", "wood"],
    difficulty: "easy",
    mapId: "grasslands",
    enemyPower: 800,
    rewards: { gold: 500, resources: { food: 200, wood: 150 }, territory: true }
  },
  {
    id: "stone_quarry",
    name: "Stone Quarry",
    x: 60,
    y: 30,
    controlled: false,
    contested: false,
    resources: ["stone", "gold"],
    difficulty: "medium",
    mapId: "grasslands",
    enemyPower: 1500,
    rewards: { gold: 800, resources: { stone: 300, gold: 200 }, territory: true }
  },
  {
    id: "desert_oasis",
    name: "Desert Oasis",
    x: 70,
    y: 60,
    controlled: false,
    contested: false,
    resources: ["gold", "power"],
    difficulty: "hard",
    mapId: "desert",
    enemyPower: 2500,
    rewards: { gold: 1200, resources: { gold: 400, power: 50 }, territory: true }
  },
  {
    id: "frozen_fortress",
    name: "Frozen Fortress",
    x: 30,
    y: 15,
    controlled: false,
    contested: false,
    resources: ["stone", "power"],
    difficulty: "expert",
    mapId: "winter",
    enemyPower: 4000,
    rewards: { gold: 2000, resources: { stone: 500, power: 100 }, territory: true }
  },
  {
    id: "volcanic_mines",
    name: "Volcanic Mines",
    x: 80,
    y: 80,
    controlled: false,
    contested: false,
    resources: ["gold", "stone", "power"],
    difficulty: "expert",
    mapId: "volcanic",
    enemyPower: 5000,
    rewards: { gold: 3000, resources: { gold: 600, stone: 400, power: 150 }, territory: true }
  }
];

const difficultyColors = {
  easy: "text-green-500 border-green-500",
  medium: "text-yellow-500 border-yellow-500", 
  hard: "text-orange-500 border-orange-500",
  expert: "text-red-500 border-red-500"
};

export default function WorldMap() {
  const [selectedTerritory, setSelectedTerritory] = useState<Territory | null>(null);
  const [showWorldMap, setShowWorldMap] = useState(false);
  const { selectMap, maps } = useGameState();
  const { armyPower, resources } = useEmpire();

  const controlledTerritories = territories.filter(t => t.controlled).length;
  const totalTerritories = territories.length;

  const canAttackTerritory = (territory: Territory) => {
    return armyPower >= territory.enemyPower * 0.8; // Need 80% of enemy power to attack
  };

  const handleAttackTerritory = (territory: Territory) => {
    // Switch to the territory's map for battle
    const map = maps.find(m => m.id === territory.mapId);
    if (map && map.unlocked) {
      selectMap(territory.mapId);
      setShowWorldMap(false);
    }
  };

  if (!showWorldMap) {
    return (
      <Button
        onClick={() => setShowWorldMap(true)}
        variant="outline"
        size="sm"
        className="fixed top-4 left-4 bg-black/80 text-white border-purple-500 hover:bg-purple-500/20"
      >
        <Map className="w-4 h-4 mr-2" />
        World Map
      </Button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg p-6 max-w-6xl w-full max-h-[90vh] overflow-y-auto m-4 text-white">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Globe className="w-8 h-8 text-purple-500" />
            <div>
              <h2 className="text-2xl font-bold">World Conquest</h2>
              <p className="text-gray-400">Expand your empire across the realm</p>
            </div>
          </div>
          <Button
            onClick={() => setShowWorldMap(false)}
            variant="outline"
            className="border-gray-600"
          >
            Close
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* World Map Visualization */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-800 border-gray-600">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2">
                  <Map className="w-5 h-5 text-purple-500" />
                  Strategic Map
                </CardTitle>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Controlled</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Enemy</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span>Contested</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div 
                  className="relative bg-gray-700 rounded-lg overflow-hidden"
                  style={{ height: "400px", width: "100%" }}
                >
                  {/* Background terrain */}
                  <div className="absolute inset-0 bg-gradient-to-br from-green-900/30 via-yellow-900/20 to-blue-900/30"></div>
                  
                  {/* Territories */}
                  {territories.map((territory) => (
                    <div
                      key={territory.id}
                      className={`absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-all hover:scale-110 ${
                        selectedTerritory?.id === territory.id ? 'ring-2 ring-purple-500' : ''
                      }`}
                      style={{ 
                        left: `${territory.x}%`, 
                        top: `${territory.y}%` 
                      }}
                      onClick={() => setSelectedTerritory(territory)}
                    >
                      <div className={`w-6 h-6 rounded-full ${
                        territory.controlled 
                          ? 'bg-green-500' 
                          : territory.contested 
                            ? 'bg-yellow-500' 
                            : 'bg-red-500'
                      } flex items-center justify-center`}>
                        {territory.controlled && <Crown className="w-3 h-3 text-white" />}
                        {territory.contested && <Sword className="w-3 h-3 text-white" />}
                        {!territory.controlled && !territory.contested && <Flag className="w-3 h-3 text-white" />}
                      </div>
                      <div className="absolute top-6 left-1/2 transform -translate-x-1/2 text-xs text-white bg-black/70 px-2 py-1 rounded whitespace-nowrap">
                        {territory.name}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Empire Stats */}
            <Card className="bg-gray-800 border-gray-600 mt-4">
              <CardContent className="p-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Trophy className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm text-gray-400">Territories</span>
                    </div>
                    <div className="text-xl font-bold">{controlledTerritories}/{totalTerritories}</div>
                    <Progress value={(controlledTerritories / totalTerritories) * 100} className="h-2 mt-1" />
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Zap className="w-4 h-4 text-red-500" />
                      <span className="text-sm text-gray-400">Army Power</span>
                    </div>
                    <div className="text-xl font-bold">{armyPower.toLocaleString()}</div>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <Users className="w-4 h-4 text-blue-500" />
                      <span className="text-sm text-gray-400">Alliance</span>
                    </div>
                    <div className="text-sm">None</div>
                    <Button variant="outline" size="sm" className="mt-1">Join</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Territory Details */}
          <div className="space-y-4">
            {selectedTerritory ? (
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{selectedTerritory.name}</CardTitle>
                    <Badge variant="outline" className={difficultyColors[selectedTerritory.difficulty]}>
                      {selectedTerritory.difficulty}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedTerritory.controlled ? (
                    <div className="flex items-center gap-2 text-green-500">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm">Territory Controlled</span>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">Enemy Power</span>
                          <span className="font-mono">{selectedTerritory.enemyPower.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">Your Power</span>
                          <span className={`font-mono ${
                            canAttackTerritory(selectedTerritory) ? 'text-green-500' : 'text-red-500'
                          }`}>
                            {armyPower.toLocaleString()}
                          </span>
                        </div>
                        <Progress 
                          value={Math.min((armyPower / selectedTerritory.enemyPower) * 100, 100)}
                          className="h-2"
                        />
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-semibold text-gray-300">Resources</h4>
                        <div className="flex flex-wrap gap-1">
                          {selectedTerritory.resources.map((resource) => (
                            <Badge key={resource} variant="secondary" className="text-xs">
                              {resource}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-semibold text-gray-300">Victory Rewards</h4>
                        <div className="text-xs text-gray-400 space-y-1">
                          <div>Gold: +{selectedTerritory.rewards.gold}</div>
                          {Object.entries(selectedTerritory.rewards.resources).map(([res, amount]) => (
                            <div key={res}>{res}: +{amount}</div>
                          ))}
                        </div>
                      </div>

                      <Button
                        onClick={() => handleAttackTerritory(selectedTerritory)}
                        disabled={!canAttackTerritory(selectedTerritory)}
                        className="w-full"
                        variant={canAttackTerritory(selectedTerritory) ? "default" : "outline"}
                      >
                        {canAttackTerritory(selectedTerritory) ? (
                          <>
                            <Target className="w-4 h-4 mr-2" />
                            Attack Territory
                          </>
                        ) : (
                          <>
                            <Lock className="w-4 h-4 mr-2" />
                            Need More Power
                          </>
                        )}
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-6 text-center text-gray-400">
                  <Map className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Select a territory to view details</p>
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <Card className="bg-gray-800 border-gray-600">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Alliance War
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Sword className="w-4 h-4 mr-2" />
                  Rally Troops
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Globe className="w-4 h-4 mr-2" />
                  Trade Routes
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}