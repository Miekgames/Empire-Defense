import { useBuildings } from "../lib/stores/useBuildings";
import { memo } from "react";
import * as THREE from "three";

const Building = memo(({ building }: { building: any }) => {
  const isResourceBuilding = building.resourceType !== undefined;
  const colors: Record<string, string> = {
    tower: '#8B4513',
    wall: '#696969', 
    house: '#D2691E',
    barracks: '#4169E1',
    throne: '#FFD700',
    forge: '#B8860B',
    market: '#20B2AA',
    temple: '#DDA0DD',
    watchtower: '#2F4F4F',
    gatehouse: '#8B4513',
    farm: '#32CD32',
    lumbermill: '#8B4513',
    quarry: '#708090',
    goldmine: '#FFD700',
    powerplant: '#FF4500'
  };

  const heights: Record<string, number> = {
    tower: 2,
    wall: 1,
    house: 1.5,
    barracks: 1.8,
    throne: 2.5,
    forge: 1.2,
    market: 1.4,
    temple: 2.2,
    watchtower: 3,
    gatehouse: 2.8,
    farm: 1,
    lumbermill: 1.6,
    quarry: 1.3,
    goldmine: 1.5,
    powerplant: 2.4
  };

  const buildingType = building.type;

  return (
    <mesh 
      position={[building.x, heights[buildingType] / 2, building.z]} 
      castShadow
    >
      <boxGeometry args={[0.8, heights[buildingType], 0.8]} />
      <meshLambertMaterial color={colors[buildingType]} />
      
      {/* Health bar for damaged buildings */}
      {building.health < building.maxHealth && (
        <mesh position={[0, heights[buildingType] / 2 + 0.3, 0]}>
          <planeGeometry args={[0.8, 0.1]} />
          <meshBasicMaterial 
            color={building.health / building.maxHealth > 0.5 ? 'green' : 'red'} 
            transparent 
            opacity={0.8}
          />
        </mesh>
      )}

      {/* Production indicator for resource buildings */}
      {isResourceBuilding && (
        <mesh position={[0, heights[buildingType] + 0.2, 0]}>
          <sphereGeometry args={[0.1]} />
          <meshBasicMaterial 
            color={building.resourceType === 'food' ? '#32CD32' : 
                   building.resourceType === 'wood' ? '#8B4513' :
                   building.resourceType === 'stone' ? '#708090' :
                   building.resourceType === 'gold' ? '#FFD700' : '#FF4500'} 
            transparent 
            opacity={0.9}
          />
        </mesh>
      )}

      {/* Level indicator */}
      {building.level > 1 && (
        <mesh position={[0.3, heights[buildingType] / 2, 0.3]}>
          <sphereGeometry args={[0.05]} />
          <meshBasicMaterial color={'white'} />
        </mesh>
      )}
    </mesh>
  );
});

export default function Buildings() {
  const { buildings } = useBuildings();

  return (
    <>
      {buildings.map((building) => (
        <Building key={building.id} building={building} />
      ))}
    </>
  );
}
