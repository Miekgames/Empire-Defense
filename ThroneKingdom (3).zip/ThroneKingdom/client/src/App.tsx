import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Game from "./components/Game";
import GameUI from "./components/GameUI";
import HeroUI from "./components/HeroUI";
import MapSelection from "./components/MapSelection";
import WorldMap from "./components/WorldMap";
import MilitaryCommander from "./components/MilitaryCommander";
import GameStats from "./components/GameStats";
import "@fontsource/inter";

const queryClient = new QueryClient();

function CanvasWrapper() {
  return (
    <Canvas
      shadows
      camera={{
        position: [0, 15, 10],
        fov: 45,
        near: 0.1,
        far: 1000
      }}
      gl={{
        antialias: true,
        powerPreference: "high-performance"
      }}
    >
      <color attach="background" args={["#87CEEB"]} />

      {/* Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight
        position={[10, 10, 5]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />

      <Suspense fallback={null}>
        <Game />
      </Suspense>
    </Canvas>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
        <CanvasWrapper />
        <GameUI />
        <HeroUI />
        <MapSelection />
        <WorldMap />
        <MilitaryCommander />
        <GameStats />
      </div>
    </QueryClientProvider>
  );
}

export default App;