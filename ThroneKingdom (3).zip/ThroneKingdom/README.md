# Empire Defense - Thronefall + Rise of Kingdoms Strategy Game

A comprehensive 3D empire-building and kingdom defense game combining Thronefall's tactical defense mechanics with Rise of Kingdoms' strategic empire management.

## Play Online

**Live Game:** [https://yourusername.github.io/empire-defense/](https://yourusername.github.io/empire-defense/)

## Game Features

### Tactical Defense Layer (Thronefall-inspired)
- **Hero Classes**: Choose from knight, archer, or mage with unique skill trees
- **Building System**: Place towers, walls, houses, barracks, and specialized structures
- **Enemy Waves**: Fight against 12 different enemy types including wizards, giants, and necromancers
- **Resource Buildings**: Farm, Lumbermill, Quarry, Gold Mine, and Power Plant for automatic resource generation

### Strategic Empire Layer (Rise of Kingdoms-inspired)
- **5-Resource Economy**: Food, wood, stone, gold, and power with production chains
- **Technology Research**: 5 research trees with agriculture, construction, military, research, and economy
- **City Building**: Economic, military, research, and infrastructure buildings
- **Military Training**: 6 troop types with training queues and army composition

### Advanced Systems
- **World Map**: Territorial conquest with 5 territories across different biomes
- **Dynamic Weather**: Weather effects affecting gameplay
- **Boss Encounters**: Special boss sieges every 5 waves
- **Crafting System**: Tower modifications using gathered materials

## Quick Start

1. Select your hero class (Knight, Archer, or Mage)
2. Place defensive buildings during the building phase
3. Build resource generators for your empire
4. Start waves to defend against enemies
5. Use empire resources to research technology and train troops
6. Expand your territory through conquest

## Building Types

### Defense Buildings
- **Tower**: Basic attack structure
- **Wall**: Blocks enemy movement
- **Watchtower**: Long-range attacks

### Resource Buildings
- **Farm**: Produces food
- **Lumbermill**: Produces wood
- **Quarry**: Produces stone
- **Gold Mine**: Produces gold
- **Power Plant**: Produces power

### Special Buildings
- **Barracks**: Trains military units
- **Forge**: Crafts upgrades
- **Temple**: Provides kingdom buffs

## Development

Built with:
- React 18 + TypeScript
- Three.js + React Three Fiber for 3D graphics
- Zustand for state management
- Tailwind CSS + shadcn/ui for styling
- Vite for building

## Local Development

```bash
npm install
npm run dev
```

## Deploy to GitHub Pages

1. Fork this repository
2. Go to Settings > Pages in your repository
3. Select "GitHub Actions" as the source
4. The game will automatically deploy to `https://yourusername.github.io/empire-defense/`

## Controls

- **Mouse**: Click to place buildings and interact with UI
- **Building Phase**: Select buildings from the panel and place them on the grid
- **Empire Management**: Use the panels on the right, top-left, and left for empire features

## Tips

- Balance defense buildings with resource production
- Upgrade buildings to increase their effectiveness
- Research technology to unlock new capabilities
- Train diverse army compositions for territorial conquest
- Build temples to maintain population happiness